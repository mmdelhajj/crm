#!/bin/bash

# RADIUS Management System Deployment Script
# Author: Manus AI
# Version: 1.0

set -e

# Colors
GREEN=\'\033[0;32m\'
RED=\'\033[0;31m\'
NC=\'\033[0m\'

log() {
    echo -e "${GREEN}[INFO] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}"
    exit 1
}

# Load environment variables
if [ -f /opt/radius-system/config/.env ]; then
    source /opt/radius-system/config/.env
else
    error "Configuration file not found: /opt/radius-system/config/.env"
fi

# Create docker-compose.yml
create_docker_compose() {
    log "Creating docker-compose.yml..."
    
    tee /opt/radius-system/docker-compose.yml > /dev/null << EOF
version: '3.8'

services:
  user-service:
    build: ./services/user-service
    ports:
      - "8001:8000"
    env_file:
      - ./config/.env
    volumes:
      - ./services/user-service:/app

  billing-service:
    build: ./services/billing-service
    ports:
      - "8002:8000"
    env_file:
      - ./config/.env
    volumes:
      - ./services/billing-service:/app

  nas-service:
    build: ./services/nas-service
    ports:
      - "8003:8000"
    env_file:
      - ./config/.env
    volumes:
      - ./services/nas-service:/app

  frontend:
    build: ./frontend
    ports:
      - "8080:80"
    volumes:
      - ./frontend:/app

  freeradius:
    image: freeradius/freeradius-server:latest
    ports:
      - "1812:1812/udp"
      - "1813:1813/udp"
    volumes:
      - ./config/freeradius:/etc/freeradius/3.0

networks:
  default:
    driver: bridge
EOF

    log "docker-compose.yml created"
}

# Clone application code (or copy from local)
clone_code() {
    log "Cloning application code..."
    
    # Replace with your repository URL
    # git clone https://github.com/your-repo/radius-system.git /opt/radius-system/src
    
    # For now, create placeholder files
    mkdir -p /opt/radius-system/services/user-service
    echo "from fastapi import FastAPI; app = FastAPI(); @app.get('/')
def read_root(): return {'service': 'user'}" > /opt/radius-system/services/user-service/main.py
    echo "fastapi\nuvicorn" > /opt/radius-system/services/user-service/requirements.txt
    echo "FROM python:3.9-slim\nWORKDIR /app\nCOPY requirements.txt .\nRUN pip install -r requirements.txt\nCOPY . .\nCMD [\"uvicorn\", \"main:app\", \"--host\", \"0.0.0.0\", \"--port\", \"8000\"]" > /opt/radius-system/services/user-service/Dockerfile
    
    # ... create similar placeholders for other services
    
    log "Application code cloned"
}

# Build and deploy
deploy() {
    log "Building and deploying application..."
    
    cd /opt/radius-system
    
    # Build and start containers
    docker-compose up -d --build
    
    log "Application deployed successfully"
}

# Main function
main() {
    log "Starting RADIUS Management System deployment..."
    
    create_docker_compose
    clone_code
    deploy
    
    log "Deployment completed successfully!"
}

main "$@"


