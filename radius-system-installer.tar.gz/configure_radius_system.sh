#!/bin/bash

# RADIUS Management System Configuration Script
# Author: Manus AI
# Version: 1.0

set -e

# Colors
GREEN=\'\033[0;32m\'
RED=\'\033[0;31m\'
NC=\'\033[0m\'

log() {
    echo -e "${GREEN}[INFO] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}"
    exit 1
}

# Load environment variables
if [ -f /opt/radius-system/config/.env ]; then
    source /opt/radius-system/config/.env
else
    error "Configuration file not found: /opt/radius-system/config/.env"
fi

# Configure PostgreSQL
configure_postgresql() {
    log "Configuring PostgreSQL..."
    
    # Import RADIUS schema
    sudo -u postgres psql radius_db < /etc/freeradius/3.0/mods-config/sql/main/postgresql/schema.sql
    
    # Import application schema
    # (Assuming schema.sql is provided with the application code)
    # sudo -u postgres psql app_db < /opt/radius-system/services/user-service/schema.sql
    
    log "PostgreSQL configured"
}

# Configure FreeRADIUS
configure_freeradius() {
    log "Configuring FreeRADIUS..."
    
    # Configure SQL module
    sudo sed -i "s/driver = \"rlm_sql_null\"/driver = \"rlm_sql_postgresql\"/" /etc/freeradius/3.0/mods-available/sql
    sudo sed -i "s/dialect = \"sqlite\"/dialect = \"postgresql\"/" /etc/freeradius/3.0/mods-available/sql
    sudo sed -i "s/server = \"localhost\"/server = \"$RADIUS_DB_HOST\"/" /etc/freeradius/3.0/mods-available/sql
    sudo sed -i "s/port = 5432/port = $RADIUS_DB_PORT/" /etc/freeradius/3.0/mods-available/sql
    sudo sed -i "s/login = \"radius\"/login = \"$RADIUS_DB_USER\"/" /etc/freeradius/3.0/mods-available/sql
    sudo sed -i "s/password = \"radpass\"/password = \"$RADIUS_DB_PASSWORD\"/" /etc/freeradius/3.0/mods-available/sql
    sudo sed -i "s/radius_db = \"radius\"/radius_db = \"$RADIUS_DB_NAME\"/" /etc/freeradius/3.0/mods-available/sql
    
    # Enable SQL module
    sudo ln -sf /etc/freeradius/3.0/mods-available/sql /etc/freeradius/3.0/mods-enabled/sql
    
    # Configure clients.conf
    sudo tee /etc/freeradius/3.0/clients.conf > /dev/null << EOF
client localhost {
    ipaddr = 127.0.0.1
    secret = $RADIUS_SECRET
}

# Add your NAS devices here
# client my_nas {
#   ipaddr = 192.168.1.100
#   secret = my_nas_secret
# }
EOF
    
    log "FreeRADIUS configured"
}

# Configure NGINX
configure_nginx() {
    log "Configuring NGINX..."
    
    # Create NGINX configuration
    sudo tee /etc/nginx/sites-available/radius-system > /dev/null << EOF
server {
    listen 80;
    server_name your_domain.com; # Replace with your domain

    location / {
        proxy_pass http://127.0.0.1:8080; # Assuming frontend runs on port 8080
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /api/ {
        proxy_pass http://127.0.0.1:8000; # API Gateway
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF
    
    # Enable the site
    sudo ln -sf /etc/nginx/sites-available/radius-system /etc/nginx/sites-enabled/
    
    # Test NGINX configuration
    sudo nginx -t
    
    # Reload NGINX
    sudo systemctl reload nginx
    
    log "NGINX configured"
}

# Main function
main() {
    log "Starting RADIUS Management System configuration..."
    
    configure_postgresql
    configure_freeradius
    configure_nginx
    
    log "Configuration completed successfully!"
}

main "$@"


