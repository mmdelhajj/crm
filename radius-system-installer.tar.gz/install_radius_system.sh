#!/bin/bash

# RADIUS Management System Installation Script
# Compatible with Ubuntu 20.04, 22.04, and 24.04
# Author: Manus AI
# Version: 1.0

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
    exit 1
}

# Check if running as root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        error "This script should not be run as root. Please run as a regular user with sudo privileges."
    fi
}

# Check Ubuntu version
check_ubuntu_version() {
    if ! command -v lsb_release &> /dev/null; then
        error "lsb_release not found. Please ensure you're running on Ubuntu."
    fi
    
    UBUNTU_VERSION=$(lsb_release -rs)
    UBUNTU_CODENAME=$(lsb_release -cs)
    
    log "Detected Ubuntu $UBUNTU_VERSION ($UBUNTU_CODENAME)"
    
    case $UBUNTU_VERSION in
        20.04|22.04|24.04)
            log "Ubuntu version is supported"
            ;;
        *)
            warn "Ubuntu version $UBUNTU_VERSION may not be fully supported. Continuing anyway..."
            ;;
    esac
}

# Check system requirements
check_requirements() {
    log "Checking system requirements..."
    
    # Check RAM
    TOTAL_RAM=$(free -m | awk 'NR==2{printf "%.0f", $2/1024}')
    if [ "$TOTAL_RAM" -lt 2 ]; then
        error "Minimum 2GB RAM required. Found: ${TOTAL_RAM}GB"
    fi
    log "RAM: ${TOTAL_RAM}GB ✓"
    
    # Check disk space
    AVAILABLE_SPACE=$(df / | awk 'NR==2 {print $4}')
    AVAILABLE_SPACE_GB=$((AVAILABLE_SPACE / 1024 / 1024))
    if [ "$AVAILABLE_SPACE_GB" -lt 10 ]; then
        error "Minimum 10GB free disk space required. Found: ${AVAILABLE_SPACE_GB}GB"
    fi
    log "Disk space: ${AVAILABLE_SPACE_GB}GB available ✓"
    
    # Check sudo privileges
    if ! sudo -n true 2>/dev/null; then
        error "This script requires sudo privileges. Please run: sudo -v"
    fi
    log "Sudo privileges ✓"
}

# Update system packages
update_system() {
    log "Updating system packages..."
    sudo apt update -y
    sudo apt upgrade -y
    sudo apt install -y curl wget git unzip software-properties-common apt-transport-https ca-certificates gnupg lsb-release
}

# Install Docker
install_docker() {
    log "Installing Docker..."
    
    if command -v docker &> /dev/null; then
        log "Docker is already installed"
        return
    fi
    
    # Add Docker's official GPG key
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
    
    # Add Docker repository
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    # Install Docker
    sudo apt update -y
    sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
    
    # Add user to docker group
    sudo usermod -aG docker $USER
    
    # Start and enable Docker
    sudo systemctl start docker
    sudo systemctl enable docker
    
    log "Docker installed successfully"
}

# Install Docker Compose
install_docker_compose() {
    log "Installing Docker Compose..."
    
    if command -v docker-compose &> /dev/null; then
        log "Docker Compose is already installed"
        return
    fi
    
    # Install Docker Compose
    DOCKER_COMPOSE_VERSION="2.21.0"
    sudo curl -L "https://github.com/docker/compose/releases/download/v${DOCKER_COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
    
    # Create symlink for compatibility
    sudo ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
    
    log "Docker Compose installed successfully"
}

# Install Node.js
install_nodejs() {
    log "Installing Node.js..."
    
    if command -v node &> /dev/null; then
        NODE_VERSION=$(node --version)
        log "Node.js is already installed: $NODE_VERSION"
        return
    fi
    
    # Install Node.js 18.x
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt install -y nodejs
    
    # Install yarn
    npm install -g yarn
    
    log "Node.js installed successfully"
}

# Install Python and dependencies
install_python() {
    log "Installing Python and dependencies..."
    
    sudo apt install -y python3 python3-pip python3-venv python3-dev build-essential libpq-dev
    
    # Upgrade pip
    python3 -m pip install --upgrade pip
    
    log "Python installed successfully"
}

# Install PostgreSQL
install_postgresql() {
    log "Installing PostgreSQL..."
    
    if command -v psql &> /dev/null; then
        log "PostgreSQL is already installed"
        return
    fi
    
    sudo apt install -y postgresql postgresql-contrib
    
    # Start and enable PostgreSQL
    sudo systemctl start postgresql
    sudo systemctl enable postgresql
    
    log "PostgreSQL installed successfully"
}

# Install Redis
install_redis() {
    log "Installing Redis..."
    
    if command -v redis-server &> /dev/null; then
        log "Redis is already installed"
        return
    fi
    
    sudo apt install -y redis-server
    
    # Configure Redis
    sudo sed -i 's/supervised no/supervised systemd/' /etc/redis/redis.conf
    
    # Start and enable Redis
    sudo systemctl start redis-server
    sudo systemctl enable redis-server
    
    log "Redis installed successfully"
}

# Install FreeRADIUS
install_freeradius() {
    log "Installing FreeRADIUS..."
    
    if command -v radiusd &> /dev/null; then
        log "FreeRADIUS is already installed"
        return
    fi
    
    sudo apt install -y freeradius freeradius-postgresql freeradius-utils
    
    # Stop FreeRADIUS for now (will be configured later)
    sudo systemctl stop freeradius
    sudo systemctl disable freeradius
    
    log "FreeRADIUS installed successfully"
}

# Install NGINX
install_nginx() {
    log "Installing NGINX..."
    
    if command -v nginx &> /dev/null; then
        log "NGINX is already installed"
        return
    fi
    
    sudo apt install -y nginx
    
    # Start and enable NGINX
    sudo systemctl start nginx
    sudo systemctl enable nginx
    
    log "NGINX installed successfully"
}

# Create project directory structure
create_project_structure() {
    log "Creating project directory structure..."
    
    PROJECT_DIR="/opt/radius-system"
    
    sudo mkdir -p $PROJECT_DIR
    sudo chown $USER:$USER $PROJECT_DIR
    
    cd $PROJECT_DIR
    
    # Create directory structure
    mkdir -p {services,frontend,config,data,logs,scripts,ssl}
    mkdir -p services/{user-service,billing-service,nas-service,reporting-service,notification-service}
    mkdir -p config/{nginx,freeradius,postgresql,redis}
    mkdir -p data/{postgresql,redis,uploads}
    
    log "Project structure created at $PROJECT_DIR"
}

# Configure firewall
configure_firewall() {
    log "Configuring firewall..."
    
    # Install UFW if not present
    sudo apt install -y ufw
    
    # Reset UFW to defaults
    sudo ufw --force reset
    
    # Set default policies
    sudo ufw default deny incoming
    sudo ufw default allow outgoing
    
    # Allow SSH
    sudo ufw allow ssh
    
    # Allow HTTP and HTTPS
    sudo ufw allow 80/tcp
    sudo ufw allow 443/tcp
    
    # Allow RADIUS ports
    sudo ufw allow 1812/udp  # RADIUS Authentication
    sudo ufw allow 1813/udp  # RADIUS Accounting
    
    # Allow PostgreSQL (local only)
    sudo ufw allow from 127.0.0.1 to any port 5432
    
    # Allow Redis (local only)
    sudo ufw allow from 127.0.0.1 to any port 6379
    
    # Enable UFW
    sudo ufw --force enable
    
    log "Firewall configured successfully"
}

# Setup database
setup_database() {
    log "Setting up PostgreSQL database..."
    
    # Generate random passwords
    DB_PASSWORD=$(openssl rand -base64 32)
    RADIUS_DB_PASSWORD=$(openssl rand -base64 32)
    
    # Create database and users
    sudo -u postgres psql << EOF
CREATE USER radius_user WITH PASSWORD '$RADIUS_DB_PASSWORD';
CREATE DATABASE radius_db OWNER radius_user;
GRANT ALL PRIVILEGES ON DATABASE radius_db TO radius_user;

CREATE USER app_user WITH PASSWORD '$DB_PASSWORD';
CREATE DATABASE app_db OWNER app_user;
GRANT ALL PRIVILEGES ON DATABASE app_db TO app_user;
EOF
    
    # Save credentials
    cat > /opt/radius-system/config/.env << EOF
# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=app_db
DB_USER=app_user
DB_PASSWORD=$DB_PASSWORD

# RADIUS Database Configuration
RADIUS_DB_HOST=localhost
RADIUS_DB_PORT=5432
RADIUS_DB_NAME=radius_db
RADIUS_DB_USER=radius_user
RADIUS_DB_PASSWORD=$RADIUS_DB_PASSWORD

# Redis Configuration
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0

# Application Configuration
SECRET_KEY=$(openssl rand -base64 64)
JWT_SECRET_KEY=$(openssl rand -base64 64)
ENVIRONMENT=production
DEBUG=false

# RADIUS Configuration
RADIUS_SECRET=$(openssl rand -base64 32)

# Email Configuration (update with your SMTP settings)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password

# SMS Configuration (update with your Twilio settings)
TWILIO_ACCOUNT_SID=your-twilio-sid
TWILIO_AUTH_TOKEN=your-twilio-token
TWILIO_PHONE_NUMBER=+1234567890
EOF
    
    chmod 600 /opt/radius-system/config/.env
    
    log "Database setup completed"
    log "Database credentials saved to /opt/radius-system/config/.env"
}

# Create systemd services
create_systemd_services() {
    log "Creating systemd services..."
    
    # Create radius-system service
    sudo tee /etc/systemd/system/radius-system.service > /dev/null << EOF
[Unit]
Description=RADIUS Management System
After=docker.service postgresql.service redis.service
Requires=docker.service postgresql.service redis.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/radius-system
ExecStart=/usr/local/bin/docker-compose up -d
ExecStop=/usr/local/bin/docker-compose down
User=$USER
Group=$USER

[Install]
WantedBy=multi-user.target
EOF
    
    sudo systemctl daemon-reload
    
    log "Systemd services created"
}

# Display completion message
display_completion() {
    log "Installation completed successfully!"
    echo
    echo -e "${BLUE}=== RADIUS Management System Installation Summary ===${NC}"
    echo -e "${GREEN}✓ System packages updated${NC}"
    echo -e "${GREEN}✓ Docker and Docker Compose installed${NC}"
    echo -e "${GREEN}✓ Node.js and Python installed${NC}"
    echo -e "${GREEN}✓ PostgreSQL and Redis installed${NC}"
    echo -e "${GREEN}✓ FreeRADIUS installed${NC}"
    echo -e "${GREEN}✓ NGINX installed${NC}"
    echo -e "${GREEN}✓ Project structure created${NC}"
    echo -e "${GREEN}✓ Firewall configured${NC}"
    echo -e "${GREEN}✓ Database setup completed${NC}"
    echo -e "${GREEN}✓ Systemd services created${NC}"
    echo
    echo -e "${YELLOW}Next Steps:${NC}"
    echo "1. Logout and login again to apply Docker group membership"
    echo "2. Run the configuration script: ./configure_radius_system.sh"
    echo "3. Deploy the application: ./deploy_radius_system.sh"
    echo
    echo -e "${YELLOW}Important Files:${NC}"
    echo "- Project directory: /opt/radius-system"
    echo "- Configuration: /opt/radius-system/config/.env"
    echo "- Logs: /opt/radius-system/logs/"
    echo
    echo -e "${YELLOW}Default Credentials:${NC}"
    echo "- Database credentials are saved in /opt/radius-system/config/.env"
    echo "- Please update email and SMS settings in the .env file"
    echo
    echo -e "${RED}Security Note:${NC}"
    echo "- Change default passwords before going to production"
    echo "- Configure SSL certificates for HTTPS"
    echo "- Review firewall settings for your environment"
}

# Main installation function
main() {
    echo -e "${BLUE}=== RADIUS Management System Installer ===${NC}"
    echo -e "${BLUE}This script will install all required components for the RADIUS Management System${NC}"
    echo
    
    read -p "Do you want to continue? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Installation cancelled."
        exit 0
    fi
    
    check_root
    check_ubuntu_version
    check_requirements
    
    update_system
    install_docker
    install_docker_compose
    install_nodejs
    install_python
    install_postgresql
    install_redis
    install_freeradius
    install_nginx
    
    create_project_structure
    configure_firewall
    setup_database
    create_systemd_services
    
    display_completion
}

# Run main function
main "$@"

