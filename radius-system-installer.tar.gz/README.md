# RADIUS Management System - Installation Guide

This guide will help you install and configure a complete RADIUS management system on Ubuntu.

## System Requirements

### Minimum Requirements
- **OS**: Ubuntu 20.04, 22.04, or 24.04 LTS
- **RAM**: 2GB minimum, 4GB recommended
- **Storage**: 10GB minimum, 20GB recommended
- **CPU**: 2 cores minimum
- **Network**: Internet connection for package downloads

### Recommended Requirements
- **RAM**: 8GB or more
- **Storage**: 50GB or more (SSD preferred)
- **CPU**: 4 cores or more
- **Network**: Static IP address

## Pre-Installation Checklist

Before running the installation scripts, ensure:

1. **System Access**: You have sudo privileges on the Ubuntu server
2. **Network**: Server has internet connectivity
3. **Firewall**: You can modify firewall rules
4. **Domain**: (Optional) You have a domain name pointing to your server
5. **Email**: SMTP credentials for email notifications
6. **SMS**: (Optional) Twilio credentials for SMS notifications

## Installation Process

### Step 1: Download Installation Scripts

```bash
# Download the installation package
wget https://your-server.com/radius-system-installer.tar.gz
tar -xzf radius-system-installer.tar.gz
cd radius-system-installer

# Or if you have the scripts locally:
chmod +x *.sh
```

### Step 2: Run System Installation

```bash
# Run the main installation script
./install_radius_system.sh
```

This script will:
- Update system packages
- Install Docker and Docker Compose
- Install Node.js and Python
- Install PostgreSQL and Redis
- Install FreeRADIUS and NGINX
- Create project directory structure
- Configure firewall
- Setup databases
- Create systemd services

**Important**: After installation, logout and login again to apply Docker group membership.

### Step 3: Configure the System

```bash
# Run the configuration script
./configure_radius_system.sh
```

This script will:
- Configure PostgreSQL with RADIUS schema
- Configure FreeRADIUS with database integration
- Configure NGINX as reverse proxy
- Set up SSL certificates (if domain is provided)

### Step 4: Deploy the Application

```bash
# Run the deployment script
./deploy_radius_system.sh
```

This script will:
- Create Docker Compose configuration
- Build and deploy application containers
- Start all services

### Step 5: Test the Installation

```bash
# Run the test script
./test_radius_system.sh
```

This script will verify:
- System services are running
- Database connectivity
- FreeRADIUS configuration
- Docker containers
- Web services
- Network connectivity
- Firewall configuration
- System resources

## Post-Installation Configuration

### 1. Update Environment Variables

Edit the configuration file:
```bash
sudo nano /opt/radius-system/config/.env
```

Update the following settings:
- **Email Configuration**: SMTP settings for notifications
- **SMS Configuration**: Twilio settings for SMS
- **Domain Settings**: Your domain name
- **Security Keys**: Change default passwords and secrets

### 2. Configure SSL/HTTPS

For production use, configure SSL certificates:

```bash
# Install Certbot for Let's Encrypt
sudo apt install certbot python3-certbot-nginx

# Obtain SSL certificate
sudo certbot --nginx -d your-domain.com

# Test automatic renewal
sudo certbot renew --dry-run
```

### 3. Configure NAS Devices

Add your network access servers to FreeRADIUS:

```bash
sudo nano /etc/freeradius/3.0/clients.conf
```

Add entries for each NAS device:
```
client my_router {
    ipaddr = 192.168.1.1
    secret = your_shared_secret
    shortname = router1
}
```

### 4. Create Admin User

Access the web interface and create your first admin user:
1. Open http://your-server-ip in a browser
2. Complete the initial setup wizard
3. Create admin account
4. Configure service plans

## Service Management

### Starting/Stopping Services

```bash
# Start all services
sudo systemctl start radius-system

# Stop all services
sudo systemctl stop radius-system

# Check service status
sudo systemctl status radius-system

# View logs
sudo journalctl -u radius-system -f
```

### Individual Service Management

```bash
# PostgreSQL
sudo systemctl start/stop/restart postgresql

# Redis
sudo systemctl start/stop/restart redis-server

# FreeRADIUS
sudo systemctl start/stop/restart freeradius

# NGINX
sudo systemctl start/stop/restart nginx

# Docker
sudo systemctl start/stop/restart docker
```

## Monitoring and Maintenance

### Log Files

- **Application Logs**: `/opt/radius-system/logs/`
- **FreeRADIUS Logs**: `/var/log/freeradius/`
- **NGINX Logs**: `/var/log/nginx/`
- **PostgreSQL Logs**: `/var/log/postgresql/`
- **System Logs**: `journalctl -u radius-system`

### Database Backup

```bash
# Backup application database
pg_dump -h localhost -U app_user app_db > backup_app_$(date +%Y%m%d).sql

# Backup RADIUS database
pg_dump -h localhost -U radius_user radius_db > backup_radius_$(date +%Y%m%d).sql
```

### System Updates

```bash
# Update system packages
sudo apt update && sudo apt upgrade

# Update Docker images
cd /opt/radius-system
docker-compose pull
docker-compose up -d
```

## Troubleshooting

### Common Issues

1. **Docker Permission Denied**
   ```bash
   # Add user to docker group and re-login
   sudo usermod -aG docker $USER
   # Then logout and login again
   ```

2. **Database Connection Failed**
   ```bash
   # Check PostgreSQL status
   sudo systemctl status postgresql
   
   # Check database credentials in .env file
   cat /opt/radius-system/config/.env
   ```

3. **FreeRADIUS Not Starting**
   ```bash
   # Test configuration
   sudo radiusd -C
   
   # Check logs
   sudo tail -f /var/log/freeradius/radius.log
   ```

4. **Web Interface Not Accessible**
   ```bash
   # Check NGINX status
   sudo systemctl status nginx
   
   # Check firewall
   sudo ufw status
   
   # Check Docker containers
   cd /opt/radius-system
   docker-compose ps
   ```

### Getting Help

1. **Check Logs**: Always check relevant log files first
2. **Run Tests**: Use `./test_radius_system.sh` to identify issues
3. **Check Documentation**: Refer to component-specific documentation
4. **Community Support**: Check project forums or GitHub issues

## Security Considerations

### Production Deployment

1. **Change Default Passwords**: Update all default passwords in `.env`
2. **Configure SSL**: Use HTTPS for web interface
3. **Firewall Rules**: Restrict access to necessary ports only
4. **Regular Updates**: Keep system and applications updated
5. **Backup Strategy**: Implement regular database backups
6. **Monitoring**: Set up monitoring and alerting
7. **Access Control**: Use strong authentication and authorization

### Network Security

1. **RADIUS Secrets**: Use strong shared secrets for NAS devices
2. **Database Security**: Restrict database access to localhost
3. **API Security**: Implement rate limiting and authentication
4. **Log Monitoring**: Monitor logs for suspicious activity

## Performance Optimization

### Database Optimization

1. **Connection Pooling**: Configure appropriate pool sizes
2. **Indexing**: Ensure proper database indexing
3. **Maintenance**: Regular VACUUM and ANALYZE operations
4. **Monitoring**: Monitor query performance

### Application Optimization

1. **Caching**: Configure Redis caching appropriately
2. **Load Balancing**: Use multiple application instances
3. **Resource Limits**: Set appropriate Docker resource limits
4. **Monitoring**: Monitor application performance metrics

## Scaling

### Horizontal Scaling

1. **Load Balancer**: Add load balancer for multiple app instances
2. **Database Clustering**: Set up PostgreSQL clustering
3. **Redis Clustering**: Configure Redis cluster for high availability
4. **Container Orchestration**: Use Kubernetes for large deployments

### Vertical Scaling

1. **Increase Resources**: Add more CPU, RAM, and storage
2. **Optimize Configuration**: Tune database and application settings
3. **Monitor Performance**: Use monitoring tools to identify bottlenecks

## Support and Maintenance

### Regular Maintenance Tasks

1. **Weekly**: Check system logs and performance
2. **Monthly**: Update system packages and applications
3. **Quarterly**: Review security settings and access logs
4. **Annually**: Review and update disaster recovery procedures

### Backup and Recovery

1. **Database Backups**: Daily automated backups
2. **Configuration Backups**: Version control for configurations
3. **Disaster Recovery**: Test recovery procedures regularly
4. **Documentation**: Keep installation and configuration documented

---

## Quick Reference

### Important Directories
- **Project Root**: `/opt/radius-system/`
- **Configuration**: `/opt/radius-system/config/`
- **Logs**: `/opt/radius-system/logs/`
- **Data**: `/opt/radius-system/data/`

### Important Files
- **Environment**: `/opt/radius-system/config/.env`
- **Docker Compose**: `/opt/radius-system/docker-compose.yml`
- **NGINX Config**: `/etc/nginx/sites-available/radius-system`
- **FreeRADIUS Config**: `/etc/freeradius/3.0/`

### Default Ports
- **Web Interface**: 80 (HTTP), 443 (HTTPS)
- **RADIUS Auth**: 1812/UDP
- **RADIUS Accounting**: 1813/UDP
- **PostgreSQL**: 5432
- **Redis**: 6379
- **API Services**: 8001-8003

### Useful Commands
```bash
# Check all services
./test_radius_system.sh

# View logs
sudo journalctl -u radius-system -f

# Restart system
sudo systemctl restart radius-system

# Check Docker containers
cd /opt/radius-system && docker-compose ps

# Database backup
pg_dump -h localhost -U app_user app_db > backup.sql
```

For additional support, please refer to the detailed implementation guide or contact the development team.

