#!/bin/bash

# RADIUS Management System Testing Script
# Author: Manus AI
# Version: 1.0

set -e

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[INFO] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[WARN] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}"
}

success() {
    echo -e "${GREEN}[SUCCESS] $1${NC}"
}

# Test system services
test_system_services() {
    log "Testing system services..."
    
    # Test PostgreSQL
    if systemctl is-active --quiet postgresql; then
        success "PostgreSQL is running"
    else
        error "PostgreSQL is not running"
        return 1
    fi
    
    # Test Redis
    if systemctl is-active --quiet redis-server; then
        success "Redis is running"
    else
        error "Redis is not running"
        return 1
    fi
    
    # Test NGINX
    if systemctl is-active --quiet nginx; then
        success "NGINX is running"
    else
        error "NGINX is not running"
        return 1
    fi
    
    # Test Docker
    if systemctl is-active --quiet docker; then
        success "Docker is running"
    else
        error "Docker is not running"
        return 1
    fi
}

# Test database connectivity
test_database() {
    log "Testing database connectivity..."
    
    # Load environment variables
    if [ -f /opt/radius-system/config/.env ]; then
        source /opt/radius-system/config/.env
    else
        error "Configuration file not found"
        return 1
    fi
    
    # Test PostgreSQL connection
    if PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -U $DB_USER -d $DB_NAME -c "SELECT 1;" > /dev/null 2>&1; then
        success "Application database connection successful"
    else
        error "Application database connection failed"
        return 1
    fi
    
    # Test RADIUS database connection
    if PGPASSWORD=$RADIUS_DB_PASSWORD psql -h $RADIUS_DB_HOST -U $RADIUS_DB_USER -d $RADIUS_DB_NAME -c "SELECT 1;" > /dev/null 2>&1; then
        success "RADIUS database connection successful"
    else
        error "RADIUS database connection failed"
        return 1
    fi
    
    # Test Redis connection
    if redis-cli ping > /dev/null 2>&1; then
        success "Redis connection successful"
    else
        error "Redis connection failed"
        return 1
    fi
}

# Test FreeRADIUS
test_freeradius() {
    log "Testing FreeRADIUS..."
    
    # Test FreeRADIUS configuration
    if sudo radiusd -C > /dev/null 2>&1; then
        success "FreeRADIUS configuration is valid"
    else
        error "FreeRADIUS configuration is invalid"
        return 1
    fi
    
    # Test RADIUS authentication (requires test user)
    # This would need a test user in the database
    # radtest testuser testpass localhost 0 testing123
}

# Test Docker containers
test_docker_containers() {
    log "Testing Docker containers..."
    
    cd /opt/radius-system
    
    # Check if docker-compose.yml exists
    if [ ! -f docker-compose.yml ]; then
        warn "docker-compose.yml not found, skipping container tests"
        return 0
    fi
    
    # Get container status
    CONTAINERS=$(docker-compose ps -q)
    
    if [ -z "$CONTAINERS" ]; then
        warn "No containers are running"
        return 0
    fi
    
    # Check each container
    for container in $CONTAINERS; do
        CONTAINER_NAME=$(docker inspect --format='{{.Name}}' $container | sed 's/\///')
        if [ "$(docker inspect --format='{{.State.Status}}' $container)" = "running" ]; then
            success "Container $CONTAINER_NAME is running"
        else
            error "Container $CONTAINER_NAME is not running"
        fi
    done
}

# Test web services
test_web_services() {
    log "Testing web services..."
    
    # Test NGINX
    if curl -s -o /dev/null -w "%{http_code}" http://localhost | grep -q "200\|301\|302"; then
        success "NGINX is responding"
    else
        warn "NGINX is not responding on port 80"
    fi
    
    # Test API endpoints (if containers are running)
    if curl -s -o /dev/null -w "%{http_code}" http://localhost:8001 | grep -q "200\|404"; then
        success "User service is responding"
    else
        warn "User service is not responding on port 8001"
    fi
    
    if curl -s -o /dev/null -w "%{http_code}" http://localhost:8002 | grep -q "200\|404"; then
        success "Billing service is responding"
    else
        warn "Billing service is not responding on port 8002"
    fi
    
    if curl -s -o /dev/null -w "%{http_code}" http://localhost:8003 | grep -q "200\|404"; then
        success "NAS service is responding"
    else
        warn "NAS service is not responding on port 8003"
    fi
}

# Test network connectivity
test_network() {
    log "Testing network connectivity..."
    
    # Test RADIUS ports
    if netstat -ln | grep -q ":1812"; then
        success "RADIUS authentication port (1812) is listening"
    else
        warn "RADIUS authentication port (1812) is not listening"
    fi
    
    if netstat -ln | grep -q ":1813"; then
        success "RADIUS accounting port (1813) is listening"
    else
        warn "RADIUS accounting port (1813) is not listening"
    fi
    
    # Test web ports
    if netstat -ln | grep -q ":80"; then
        success "HTTP port (80) is listening"
    else
        warn "HTTP port (80) is not listening"
    fi
}

# Test firewall
test_firewall() {
    log "Testing firewall configuration..."
    
    if command -v ufw &> /dev/null; then
        if ufw status | grep -q "Status: active"; then
            success "UFW firewall is active"
            
            # Check specific rules
            if ufw status | grep -q "1812/udp"; then
                success "RADIUS authentication port is allowed"
            else
                warn "RADIUS authentication port may not be allowed"
            fi
            
            if ufw status | grep -q "1813/udp"; then
                success "RADIUS accounting port is allowed"
            else
                warn "RADIUS accounting port may not be allowed"
            fi
        else
            warn "UFW firewall is not active"
        fi
    else
        warn "UFW firewall is not installed"
    fi
}

# Test system resources
test_resources() {
    log "Testing system resources..."
    
    # Check memory usage
    MEMORY_USAGE=$(free | grep Mem | awk '{printf "%.0f", $3/$2 * 100.0}')
    if [ "$MEMORY_USAGE" -lt 80 ]; then
        success "Memory usage is acceptable ($MEMORY_USAGE%)"
    else
        warn "Memory usage is high ($MEMORY_USAGE%)"
    fi
    
    # Check disk usage
    DISK_USAGE=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
    if [ "$DISK_USAGE" -lt 80 ]; then
        success "Disk usage is acceptable ($DISK_USAGE%)"
    else
        warn "Disk usage is high ($DISK_USAGE%)"
    fi
    
    # Check CPU load
    CPU_LOAD=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
    CPU_CORES=$(nproc)
    if (( $(echo "$CPU_LOAD < $CPU_CORES" | bc -l) )); then
        success "CPU load is acceptable ($CPU_LOAD)"
    else
        warn "CPU load is high ($CPU_LOAD)"
    fi
}

# Generate test report
generate_report() {
    log "Generating test report..."
    
    REPORT_FILE="/opt/radius-system/logs/test-report-$(date +%Y%m%d-%H%M%S).txt"
    mkdir -p /opt/radius-system/logs
    
    {
        echo "RADIUS Management System Test Report"
        echo "Generated: $(date)"
        echo "========================================"
        echo
        echo "System Information:"
        echo "- OS: $(lsb_release -d | cut -f2)"
        echo "- Kernel: $(uname -r)"
        echo "- Uptime: $(uptime -p)"
        echo
        echo "Service Status:"
        systemctl is-active postgresql && echo "- PostgreSQL: Running" || echo "- PostgreSQL: Stopped"
        systemctl is-active redis-server && echo "- Redis: Running" || echo "- Redis: Stopped"
        systemctl is-active nginx && echo "- NGINX: Running" || echo "- NGINX: Stopped"
        systemctl is-active docker && echo "- Docker: Running" || echo "- Docker: Stopped"
        echo
        echo "Resource Usage:"
        echo "- Memory: $(free -h | grep Mem | awk '{print $3 "/" $2}')"
        echo "- Disk: $(df -h / | awk 'NR==2 {print $3 "/" $2 " (" $5 ")"}')"
        echo "- CPU Load: $(uptime | awk -F'load average:' '{print $2}')"
        echo
        echo "Network Ports:"
        netstat -ln | grep -E ":(80|443|1812|1813|5432|6379)" || echo "No relevant ports found"
    } > "$REPORT_FILE"
    
    success "Test report saved to $REPORT_FILE"
}

# Main test function
main() {
    echo -e "${GREEN}=== RADIUS Management System Test Suite ===${NC}"
    echo
    
    FAILED_TESTS=0
    
    # Run all tests
    test_system_services || ((FAILED_TESTS++))
    echo
    
    test_database || ((FAILED_TESTS++))
    echo
    
    test_freeradius || ((FAILED_TESTS++))
    echo
    
    test_docker_containers || ((FAILED_TESTS++))
    echo
    
    test_web_services || ((FAILED_TESTS++))
    echo
    
    test_network || ((FAILED_TESTS++))
    echo
    
    test_firewall || ((FAILED_TESTS++))
    echo
    
    test_resources || ((FAILED_TESTS++))
    echo
    
    generate_report
    echo
    
    # Summary
    if [ $FAILED_TESTS -eq 0 ]; then
        success "All tests passed successfully!"
    else
        warn "$FAILED_TESTS test(s) failed or showed warnings"
    fi
    
    echo -e "${GREEN}Test completed. Check the report for details.${NC}"
}

# Run main function
main "$@"

