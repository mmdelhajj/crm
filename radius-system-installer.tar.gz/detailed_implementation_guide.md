# Complete RADIUS Management System Implementation Guide

**Author:** Manus AI  
**Date:** September 17, 2025  
**Version:** 1.0

## Table of Contents

1. [System Architecture Overview](#1-system-architecture-overview)
2. [Technology Stack Selection](#2-technology-stack-selection)
3. [Development Environment Setup](#3-development-environment-setup)
4. [Core Components Implementation](#4-core-components-implementation)
5. [Database Design and Implementation](#5-database-design-and-implementation)
6. [RADIUS Server Configuration](#6-radius-server-configuration)
7. [Backend Services Development](#7-backend-services-development)
8. [Frontend Development](#8-frontend-development)
9. [Integration and APIs](#9-integration-and-apis)
10. [Security Implementation](#10-security-implementation)
11. [Testing Strategy](#11-testing-strategy)
12. [Deployment and DevOps](#12-deployment-and-devops)
13. [Monitoring and Maintenance](#13-monitoring-and-maintenance)
14. [Scaling and Performance Optimization](#14-scaling-and-performance-optimization)

## 1. System Architecture Overview

### 1.1 Microservices Architecture

The RADIUS management system should be built using a microservices architecture to ensure scalability, maintainability, and fault tolerance. The system consists of the following core services:

**Core Services:**
- **RADIUS Service**: Handles AAA operations using FreeRADIUS
- **User Management Service**: Manages subscriber accounts and profiles
- **Billing Service**: Handles invoicing, payments, and financial operations
- **NAS Management Service**: Manages network access servers
- **Reporting Service**: Generates analytics and reports
- **Notification Service**: Handles email, SMS, and push notifications
- **API Gateway**: Routes requests and handles cross-cutting concerns

**Supporting Infrastructure:**
- **Database Cluster**: PostgreSQL with read replicas
- **Cache Layer**: Redis for session management and caching
- **Message Queue**: RabbitMQ for asynchronous processing
- **File Storage**: MinIO or AWS S3 for file storage
- **Load Balancer**: NGINX or HAProxy for traffic distribution

### 1.2 Data Flow Architecture

The system follows a typical three-tier architecture:

1. **Presentation Layer**: Web interface and mobile apps
2. **Application Layer**: Microservices handling business logic
3. **Data Layer**: Database, cache, and file storage

Communication between services uses REST APIs and message queues for asynchronous operations.

## 2. Technology Stack Selection

### 2.1 Backend Technologies

**Primary Language**: Python 3.9+
- **Framework**: FastAPI (for high performance) or Flask (for simplicity)
- **ORM**: SQLAlchemy with Alembic for migrations
- **Authentication**: JWT tokens with refresh token rotation
- **Validation**: Pydantic for data validation
- **Testing**: pytest with coverage reporting

**Alternative Options**:
- **Node.js**: Express.js with TypeScript for JavaScript teams
- **Java**: Spring Boot for enterprise environments
- **Go**: Gin framework for high-performance requirements

### 2.2 Database Technologies

**Primary Database**: PostgreSQL 13+
- Excellent performance for complex queries
- Strong ACID compliance
- JSON support for flexible data structures
- Robust replication and clustering

**Cache Layer**: Redis 6+
- Session storage
- Frequently accessed data caching
- Rate limiting counters
- Real-time analytics

### 2.3 Frontend Technologies

**Web Application**: React 18+ with TypeScript
- **State Management**: Redux Toolkit or Zustand
- **UI Framework**: Material-UI or Ant Design
- **Build Tool**: Vite for fast development
- **Testing**: Jest and React Testing Library

**Mobile Applications**:
- **React Native**: For cross-platform development
- **Flutter**: Alternative for high-performance mobile apps

### 2.4 Infrastructure Technologies

**Containerization**: Docker with multi-stage builds
**Orchestration**: Kubernetes or Docker Swarm
**CI/CD**: GitLab CI/CD or GitHub Actions
**Monitoring**: Prometheus + Grafana + ELK Stack
**API Gateway**: Kong or AWS API Gateway

## 3. Development Environment Setup

### 3.1 Local Development Environment

Create a `docker-compose.yml` file for local development:

```yaml
version: '3.8'
services:
  postgres:
    image: postgres:13
    environment:
      POSTGRES_DB: radius_db
      POSTGRES_USER: radius_user
      POSTGRES_PASSWORD: radius_pass
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:6-alpine
    ports:
      - "6379:6379"

  freeradius:
    image: freeradius/freeradius-server:latest
    ports:
      - "1812:1812/udp"
      - "1813:1813/udp"
    volumes:
      - ./radius-config:/etc/freeradius

  api-gateway:
    image: kong:latest
    environment:
      KONG_DATABASE: "off"
      KONG_DECLARATIVE_CONFIG: /kong/kong.yml
    ports:
      - "8000:8000"
      - "8001:8001"
    volumes:
      - ./kong.yml:/kong/kong.yml

volumes:
  postgres_data:
```

### 3.2 Project Structure

```
radius-management-system/
├── services/
│   ├── radius-service/
│   ├── user-service/
│   ├── billing-service/
│   ├── nas-service/
│   ├── reporting-service/
│   └── notification-service/
├── frontend/
│   ├── web-app/
│   └── mobile-app/
├── infrastructure/
│   ├── docker/
│   ├── kubernetes/
│   └── terraform/
├── shared/
│   ├── models/
│   ├── utils/
│   └── config/
└── docs/
```

## 4. Core Components Implementation

### 4.1 User Management Service

The User Management Service is responsible for handling all user-related operations including registration, authentication, profile management, and service plan assignments.

**Key Features:**
- User registration and profile management
- Authentication and authorization
- Service plan assignment and management
- User status tracking (Active, Suspended, Expired)
- Bulk operations for user management

**Database Schema:**

```sql
-- Users table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    phone VARCHAR(20),
    status VARCHAR(20) DEFAULT 'active',
    service_plan_id INTEGER REFERENCES service_plans(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Service plans table
CREATE TABLE service_plans (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    download_speed INTEGER, -- in kbps
    upload_speed INTEGER,   -- in kbps
    data_quota BIGINT,      -- in bytes
    price DECIMAL(10,2),
    billing_cycle VARCHAR(20), -- monthly, daily, etc.
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User sessions table for RADIUS accounting
CREATE TABLE user_sessions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    nas_ip_address INET,
    session_id VARCHAR(100),
    start_time TIMESTAMP,
    stop_time TIMESTAMP,
    bytes_in BIGINT DEFAULT 0,
    bytes_out BIGINT DEFAULT 0,
    session_duration INTEGER DEFAULT 0
);
```

**API Implementation Example:**

```python
from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Optional
import bcrypt

app = FastAPI()

class UserCreate(BaseModel):
    username: str
    email: str
    password: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    service_plan_id: Optional[int] = None

class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    first_name: Optional[str]
    last_name: Optional[str]
    status: str
    service_plan_id: Optional[int]

@app.post("/users", response_model=UserResponse)
async def create_user(user: UserCreate, db: Session = Depends(get_db)):
    # Check if user already exists
    existing_user = db.query(User).filter(
        (User.username == user.username) | (User.email == user.email)
    ).first()
    
    if existing_user:
        raise HTTPException(status_code=400, detail="User already exists")
    
    # Hash password
    password_hash = bcrypt.hashpw(user.password.encode('utf-8'), bcrypt.gensalt())
    
    # Create user
    db_user = User(
        username=user.username,
        email=user.email,
        password_hash=password_hash.decode('utf-8'),
        first_name=user.first_name,
        last_name=user.last_name,
        phone=user.phone,
        service_plan_id=user.service_plan_id
    )
    
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    
    return db_user

@app.get("/users", response_model=List[UserResponse])
async def get_users(
    skip: int = 0, 
    limit: int = 100, 
    db: Session = Depends(get_db)
):
    users = db.query(User).offset(skip).limit(limit).all()
    return users

@app.get("/users/{user_id}", response_model=UserResponse)
async def get_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@app.put("/users/{user_id}/status")
async def update_user_status(
    user_id: int, 
    status: str, 
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.status = status
    db.commit()
    
    return {"message": "User status updated successfully"}
```

### 4.2 Billing Service

The Billing Service handles all financial operations including invoice generation, payment processing, and revenue tracking.

**Key Features:**
- Automated invoice generation
- Multiple payment gateway integration
- Subscription management
- Prepaid card system
- Financial reporting
- Tax calculation and compliance

**Database Schema:**

```sql
-- Invoices table
CREATE TABLE invoices (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    tax_amount DECIMAL(10,2) DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    due_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    paid_at TIMESTAMP
);

-- Payments table
CREATE TABLE payments (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER REFERENCES invoices(id),
    payment_method VARCHAR(50),
    transaction_id VARCHAR(100),
    amount DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    gateway_response JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Prepaid cards table
CREATE TABLE prepaid_cards (
    id SERIAL PRIMARY KEY,
    card_number VARCHAR(20) UNIQUE NOT NULL,
    pin VARCHAR(10) NOT NULL,
    value DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'active',
    used_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    used_at TIMESTAMP
);
```

### 4.3 NAS Management Service

The NAS Management Service handles network access server registration, monitoring, and configuration.

**Key Features:**
- NAS device registration and inventory
- Real-time device monitoring
- Configuration management
- Performance metrics collection
- Device grouping and organization

**Database Schema:**

```sql
-- NAS devices table
CREATE TABLE nas_devices (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    ip_address INET UNIQUE NOT NULL,
    secret VARCHAR(100) NOT NULL,
    device_type VARCHAR(50),
    vendor VARCHAR(50),
    model VARCHAR(50),
    location VARCHAR(100),
    status VARCHAR(20) DEFAULT 'active',
    last_seen TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- NAS performance metrics table
CREATE TABLE nas_metrics (
    id SERIAL PRIMARY KEY,
    nas_id INTEGER REFERENCES nas_devices(id),
    cpu_usage DECIMAL(5,2),
    memory_usage DECIMAL(5,2),
    uptime INTEGER,
    active_sessions INTEGER,
    bytes_in BIGINT,
    bytes_out BIGINT,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 5. Database Design and Implementation

### 5.1 Database Schema Design

The database schema should be designed to support high performance and scalability. Key considerations include:

**Normalization**: Use appropriate normalization levels to balance performance and data integrity.

**Indexing Strategy**: Create indexes on frequently queried columns:

```sql
-- Performance indexes
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX idx_user_sessions_start_time ON user_sessions(start_time);
CREATE INDEX idx_invoices_user_id ON invoices(user_id);
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_nas_devices_ip_address ON nas_devices(ip_address);
```

**Partitioning**: For large tables like user_sessions, consider partitioning by date:

```sql
-- Partition user_sessions table by month
CREATE TABLE user_sessions_y2025m01 PARTITION OF user_sessions
    FOR VALUES FROM ('2025-01-01') TO ('2025-02-01');
```

### 5.2 Database Connection Management

Use connection pooling to manage database connections efficiently:

```python
from sqlalchemy import create_engine
from sqlalchemy.pool import QueuePool

# Database configuration
DATABASE_URL = "postgresql://user:password@localhost/radius_db"

engine = create_engine(
    DATABASE_URL,
    poolclass=QueuePool,
    pool_size=20,
    max_overflow=30,
    pool_pre_ping=True,
    pool_recycle=3600
)
```

## 6. RADIUS Server Configuration

### 6.1 FreeRADIUS Installation and Configuration

Install FreeRADIUS and configure it to work with your database:

```bash
# Install FreeRADIUS
sudo apt-get update
sudo apt-get install freeradius freeradius-postgresql

# Enable SQL module
sudo ln -s /etc/freeradius/3.0/mods-available/sql /etc/freeradius/3.0/mods-enabled/
```

**Configure SQL module** (`/etc/freeradius/3.0/mods-enabled/sql`):

```
sql {
    driver = "rlm_sql_postgresql"
    dialect = "postgresql"
    
    server = "localhost"
    port = 5432
    login = "radius_user"
    password = "radius_pass"
    radius_db = "radius_db"
    
    # Connection pool settings
    pool {
        start = 5
        min = 4
        max = 20
        spare = 3
        uses = 0
        retry_delay = 30
        lifetime = 0
        idle_timeout = 60
    }
    
    # SQL queries
    read_clients = yes
    client_table = "nas_devices"
    
    # Authorization queries
    authorize_check_query = "SELECT id, username, attribute, value, op FROM radcheck WHERE username = '%{SQL-User-Name}' ORDER BY id"
    authorize_reply_query = "SELECT id, username, attribute, value, op FROM radreply WHERE username = '%{SQL-User-Name}' ORDER BY id"
    
    # Accounting queries
    accounting_start_query = "INSERT INTO radacct (acctsessionid, acctuniqueid, username, realm, nasipaddress, nasportid, nasporttype, acctstarttime, acctupdatetime, acctstoptime, acctsessiontime, acctauthentic, connectinfo_start, connectinfo_stop, acctinputoctets, acctoutputoctets, calledstationid, callingstationid, acctterminatecause, servicetype, framedprotocol, framedipaddress) VALUES ('%{Acct-Session-Id}', '%{Acct-Unique-Session-Id}', '%{SQL-User-Name}', '%{Realm}', '%{NAS-IP-Address}', '%{NAS-Port}', '%{NAS-Port-Type}', '%S', '%S', NULL, '0', '%{Acct-Authentic}', '%{Connect-Info}', '', '0', '0', '%{Called-Station-Id}', '%{Calling-Station-Id}', '', '%{Service-Type}', '%{Framed-Protocol}', '%{Framed-IP-Address}')"
    
    accounting_update_query = "UPDATE radacct SET framedipaddress = '%{Framed-IP-Address}', acctupdatetime = '%S', acctinputoctets = '%{Acct-Input-Octets}', acctoutputoctets = '%{Acct-Output-Octets}' WHERE acctsessionid = '%{Acct-Session-Id}' AND username = '%{SQL-User-Name}' AND nasipaddress = '%{NAS-IP-Address}'"
    
    accounting_stop_query = "UPDATE radacct SET acctstoptime = '%S', acctsessiontime = '%{Acct-Session-Time}', acctinputoctets = '%{Acct-Input-Octets}', acctoutputoctets = '%{Acct-Output-Octets}', acctterminatecause = '%{Acct-Terminate-Cause}', connectinfo_stop = '%{Connect-Info}' WHERE acctsessionid = '%{Acct-Session-Id}' AND username = '%{SQL-User-Name}' AND nasipaddress = '%{NAS-IP-Address}'"
}
```

### 6.2 RADIUS Database Schema

Create the necessary tables for FreeRADIUS:

```sql
-- RADIUS check attributes
CREATE TABLE radcheck (
    id SERIAL PRIMARY KEY,
    username VARCHAR(64) NOT NULL DEFAULT '',
    attribute VARCHAR(64) NOT NULL DEFAULT '',
    op CHAR(2) NOT NULL DEFAULT '==',
    value VARCHAR(253) NOT NULL DEFAULT ''
);

-- RADIUS reply attributes
CREATE TABLE radreply (
    id SERIAL PRIMARY KEY,
    username VARCHAR(64) NOT NULL DEFAULT '',
    attribute VARCHAR(64) NOT NULL DEFAULT '',
    op CHAR(2) NOT NULL DEFAULT '=',
    value VARCHAR(253) NOT NULL DEFAULT ''
);

-- RADIUS accounting
CREATE TABLE radacct (
    radacctid BIGSERIAL PRIMARY KEY,
    acctsessionid VARCHAR(64) NOT NULL DEFAULT '',
    acctuniqueid VARCHAR(32) NOT NULL DEFAULT '',
    username VARCHAR(64) NOT NULL DEFAULT '',
    realm VARCHAR(64) DEFAULT '',
    nasipaddress INET NOT NULL,
    nasportid VARCHAR(15),
    nasporttype VARCHAR(32),
    acctstarttime TIMESTAMP WITH TIME ZONE,
    acctupdatetime TIMESTAMP WITH TIME ZONE,
    acctstoptime TIMESTAMP WITH TIME ZONE,
    acctinterval INTEGER,
    acctsessiontime INTEGER,
    acctauthentic VARCHAR(32),
    connectinfo_start VARCHAR(50),
    connectinfo_stop VARCHAR(50),
    acctinputoctets BIGINT,
    acctoutputoctets BIGINT,
    calledstationid VARCHAR(50),
    callingstationid VARCHAR(50),
    acctterminatecause VARCHAR(32),
    servicetype VARCHAR(32),
    framedprotocol VARCHAR(32),
    framedipaddress INET
);

-- Indexes for performance
CREATE INDEX radacct_username_idx ON radacct(username);
CREATE INDEX radacct_start_time_idx ON radacct(acctstarttime);
CREATE INDEX radacct_stop_time_idx ON radacct(acctstoptime);
CREATE INDEX radcheck_username_idx ON radcheck(username);
CREATE INDEX radreply_username_idx ON radreply(username);
```

## 7. Backend Services Development

### 7.1 Service Architecture Pattern

Each microservice should follow a consistent architecture pattern:

```
service/
├── app/
│   ├── __init__.py
│   ├── main.py          # FastAPI application
│   ├── models/          # Database models
│   ├── schemas/         # Pydantic schemas
│   ├── api/             # API routes
│   ├── services/        # Business logic
│   ├── utils/           # Utility functions
│   └── config.py        # Configuration
├── tests/
├── requirements.txt
└── Dockerfile
```

### 7.2 Authentication and Authorization Service

Implement JWT-based authentication with role-based access control:

```python
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from passlib.context import CryptContext
from datetime import datetime, timedelta
from typing import Optional

app = FastAPI()
security = HTTPBearer()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

class AuthService:
    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        return pwd_context.verify(plain_password, hashed_password)
    
    def get_password_hash(self, password: str) -> str:
        return pwd_context.hash(password)
    
    def create_access_token(self, data: dict, expires_delta: Optional[timedelta] = None):
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=15)
        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
        return encoded_jwt
    
    def verify_token(self, token: str):
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            username: str = payload.get("sub")
            if username is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Could not validate credentials"
                )
            return username
        except JWTError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials"
            )

auth_service = AuthService()

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    username = auth_service.verify_token(credentials.credentials)
    # Fetch user from database
    user = get_user_by_username(username)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found"
        )
    return user

@app.post("/auth/login")
async def login(username: str, password: str):
    user = authenticate_user(username, password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password"
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = auth_service.create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}
```

### 7.3 API Gateway Configuration

Configure Kong API Gateway to handle routing, authentication, and rate limiting:

```yaml
# kong.yml
_format_version: "2.1"

services:
  - name: user-service
    url: http://user-service:8000
    routes:
      - name: user-routes
        paths:
          - /api/v1/users
        methods:
          - GET
          - POST
          - PUT
          - DELETE

  - name: billing-service
    url: http://billing-service:8000
    routes:
      - name: billing-routes
        paths:
          - /api/v1/billing
        methods:
          - GET
          - POST

plugins:
  - name: jwt
    service: user-service
    config:
      secret_is_base64: false
      key_claim_name: iss
      
  - name: rate-limiting
    service: user-service
    config:
      minute: 100
      hour: 1000
```

## 8. Frontend Development

### 8.1 React Application Structure

Create a modern React application with TypeScript:

```bash
npx create-react-app radius-admin --template typescript
cd radius-admin
npm install @mui/material @emotion/react @emotion/styled
npm install @reduxjs/toolkit react-redux
npm install axios react-router-dom
```

**Project Structure:**

```
src/
├── components/          # Reusable components
│   ├── common/
│   ├── forms/
│   └── charts/
├── pages/              # Page components
│   ├── Dashboard/
│   ├── Users/
│   ├── Billing/
│   └── Settings/
├── store/              # Redux store
│   ├── slices/
│   └── index.ts
├── services/           # API services
├── utils/              # Utility functions
├── types/              # TypeScript types
└── App.tsx
```

### 8.2 User Management Interface

Create a comprehensive user management interface:

```typescript
// src/pages/Users/UserList.tsx
import React, { useState, useEffect } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from '@mui/material';
import { Edit, Delete, Add } from '@mui/icons-material';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { fetchUsers, createUser, updateUser, deleteUser } from '../../store/slices/userSlice';

interface User {
  id: number;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
  status: string;
  service_plan_id: number;
  created_at: string;
}

const UserList: React.FC = () => {
  const dispatch = useAppDispatch();
  const { users, loading, error } = useAppSelector(state => state.users);
  const [open, setOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    first_name: '',
    last_name: '',
    status: 'active',
    service_plan_id: 1
  });

  useEffect(() => {
    dispatch(fetchUsers());
  }, [dispatch]);

  const handleSubmit = async () => {
    if (editingUser) {
      await dispatch(updateUser({ id: editingUser.id, ...formData }));
    } else {
      await dispatch(createUser(formData));
    }
    setOpen(false);
    setEditingUser(null);
    setFormData({
      username: '',
      email: '',
      first_name: '',
      last_name: '',
      status: 'active',
      service_plan_id: 1
    });
  };

  const handleEdit = (user: User) => {
    setEditingUser(user);
    setFormData({
      username: user.username,
      email: user.email,
      first_name: user.first_name,
      last_name: user.last_name,
      status: user.status,
      service_plan_id: user.service_plan_id
    });
    setOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      await dispatch(deleteUser(id));
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'success';
      case 'suspended': return 'warning';
      case 'expired': return 'error';
      default: return 'default';
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
        <h2>User Management</h2>
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={() => setOpen(true)}
        >
          Add User
        </Button>
      </div>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Username</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Name</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Service Plan</TableCell>
              <TableCell>Created</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {users.map((user) => (
              <TableRow key={user.id}>
                <TableCell>{user.username}</TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell>{`${user.first_name} ${user.last_name}`}</TableCell>
                <TableCell>
                  <Chip
                    label={user.status}
                    color={getStatusColor(user.status) as any}
                    size="small"
                  />
                </TableCell>
                <TableCell>{user.service_plan_id}</TableCell>
                <TableCell>{new Date(user.created_at).toLocaleDateString()}</TableCell>
                <TableCell>
                  <IconButton onClick={() => handleEdit(user)}>
                    <Edit />
                  </IconButton>
                  <IconButton onClick={() => handleDelete(user.id)}>
                    <Delete />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editingUser ? 'Edit User' : 'Add User'}</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="Username"
            value={formData.username}
            onChange={(e) => setFormData({ ...formData, username: e.target.value })}
            margin="normal"
          />
          <TextField
            fullWidth
            label="Email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            margin="normal"
          />
          <TextField
            fullWidth
            label="First Name"
            value={formData.first_name}
            onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
            margin="normal"
          />
          <TextField
            fullWidth
            label="Last Name"
            value={formData.last_name}
            onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
            margin="normal"
          />
          <FormControl fullWidth margin="normal">
            <InputLabel>Status</InputLabel>
            <Select
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value })}
            >
              <MenuItem value="active">Active</MenuItem>
              <MenuItem value="suspended">Suspended</MenuItem>
              <MenuItem value="expired">Expired</MenuItem>
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={handleSubmit} variant="contained">
            {editingUser ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default UserList;
```

### 8.3 Dashboard with Real-time Metrics

Create a dashboard with real-time metrics using WebSocket connections:

```typescript
// src/pages/Dashboard/Dashboard.tsx
import React, { useState, useEffect } from 'react';
import {
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  LinearProgress
} from '@mui/material';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface DashboardMetrics {
  totalUsers: number;
  activeUsers: number;
  onlineUsers: number;
  totalRevenue: number;
  systemUptime: string;
  cpuUsage: number;
  memoryUsage: number;
  diskUsage: number;
}

const Dashboard: React.FC = () => {
  const [metrics, setMetrics] = useState<DashboardMetrics>({
    totalUsers: 0,
    activeUsers: 0,
    onlineUsers: 0,
    totalRevenue: 0,
    systemUptime: '0 days',
    cpuUsage: 0,
    memoryUsage: 0,
    diskUsage: 0
  });

  const [usageData, setUsageData] = useState([]);
  const [revenueData, setRevenueData] = useState([]);

  useEffect(() => {
    // WebSocket connection for real-time updates
    const ws = new WebSocket('ws://localhost:8000/ws/dashboard');
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      setMetrics(data.metrics);
      setUsageData(data.usageData);
      setRevenueData(data.revenueData);
    };

    return () => ws.close();
  }, []);

  const MetricCard: React.FC<{ title: string; value: string | number; color?: string }> = ({
    title,
    value,
    color = 'primary'
  }) => (
    <Card>
      <CardContent>
        <Typography color="textSecondary" gutterBottom>
          {title}
        </Typography>
        <Typography variant="h4" component="div" color={color}>
          {value}
        </Typography>
      </CardContent>
    </Card>
  );

  const ProgressCard: React.FC<{ title: string; value: number; color?: string }> = ({
    title,
    value,
    color = 'primary'
  }) => (
    <Card>
      <CardContent>
        <Typography color="textSecondary" gutterBottom>
          {title}
        </Typography>
        <Box display="flex" alignItems="center">
          <Box width="100%" mr={1}>
            <LinearProgress
              variant="determinate"
              value={value}
              color={color as any}
            />
          </Box>
          <Box minWidth={35}>
            <Typography variant="body2" color="textSecondary">
              {`${Math.round(value)}%`}
            </Typography>
          </Box>
        </Box>
      </CardContent>
    </Card>
  );

  return (
    <div>
      <Typography variant="h4" gutterBottom>
        Dashboard
      </Typography>
      
      <Grid container spacing={3}>
        {/* Metric Cards */}
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard title="Total Users" value={metrics.totalUsers} />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard title="Active Users" value={metrics.activeUsers} color="success" />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard title="Online Users" value={metrics.onlineUsers} color="info" />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard title="Total Revenue" value={`$${metrics.totalRevenue.toLocaleString()}`} color="secondary" />
        </Grid>

        {/* System Health */}
        <Grid item xs={12} sm={4}>
          <ProgressCard title="CPU Usage" value={metrics.cpuUsage} />
        </Grid>
        <Grid item xs={12} sm={4}>
          <ProgressCard title="Memory Usage" value={metrics.memoryUsage} color="warning" />
        </Grid>
        <Grid item xs={12} sm={4}>
          <ProgressCard title="Disk Usage" value={metrics.diskUsage} color="error" />
        </Grid>

        {/* Usage Chart */}
        <Grid item xs={12} md={8}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                User Activity (Last 24 Hours)
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={usageData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="activeUsers" stroke="#8884d8" />
                  <Line type="monotone" dataKey="onlineUsers" stroke="#82ca9d" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Revenue Chart */}
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Revenue by Service Plan
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={revenueData}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label
                  >
                    {revenueData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={`hsl(${index * 45}, 70%, 50%)`} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </div>
  );
};

export default Dashboard;
```

## 9. Integration and APIs

### 9.1 Payment Gateway Integration

Integrate with multiple payment gateways for flexible payment processing:

```python
# services/billing-service/app/services/payment_service.py
from abc import ABC, abstractmethod
from typing import Dict, Any
import stripe
import requests

class PaymentGateway(ABC):
    @abstractmethod
    def process_payment(self, amount: float, currency: str, payment_method: str) -> Dict[str, Any]:
        pass
    
    @abstractmethod
    def create_customer(self, email: str, name: str) -> Dict[str, Any]:
        pass

class StripeGateway(PaymentGateway):
    def __init__(self, api_key: str):
        stripe.api_key = api_key
    
    def process_payment(self, amount: float, currency: str, payment_method: str) -> Dict[str, Any]:
        try:
            intent = stripe.PaymentIntent.create(
                amount=int(amount * 100),  # Convert to cents
                currency=currency,
                payment_method=payment_method,
                confirm=True
            )
            return {
                'success': True,
                'transaction_id': intent.id,
                'status': intent.status
            }
        except stripe.error.StripeError as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def create_customer(self, email: str, name: str) -> Dict[str, Any]:
        try:
            customer = stripe.Customer.create(
                email=email,
                name=name
            )
            return {
                'success': True,
                'customer_id': customer.id
            }
        except stripe.error.StripeError as e:
            return {
                'success': False,
                'error': str(e)
            }

class PayPalGateway(PaymentGateway):
    def __init__(self, client_id: str, client_secret: str, sandbox: bool = True):
        self.client_id = client_id
        self.client_secret = client_secret
        self.base_url = "https://api.sandbox.paypal.com" if sandbox else "https://api.paypal.com"
    
    def get_access_token(self) -> str:
        url = f"{self.base_url}/v1/oauth2/token"
        headers = {
            'Accept': 'application/json',
            'Accept-Language': 'en_US',
        }
        data = 'grant_type=client_credentials'
        
        response = requests.post(
            url,
            headers=headers,
            data=data,
            auth=(self.client_id, self.client_secret)
        )
        
        return response.json()['access_token']
    
    def process_payment(self, amount: float, currency: str, payment_method: str) -> Dict[str, Any]:
        access_token = self.get_access_token()
        
        url = f"{self.base_url}/v2/payments/captures"
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {access_token}',
        }
        
        payload = {
            "intent": "CAPTURE",
            "purchase_units": [{
                "amount": {
                    "currency_code": currency,
                    "value": str(amount)
                }
            }]
        }
        
        response = requests.post(url, json=payload, headers=headers)
        
        if response.status_code == 201:
            return {
                'success': True,
                'transaction_id': response.json()['id'],
                'status': 'completed'
            }
        else:
            return {
                'success': False,
                'error': response.json().get('message', 'Payment failed')
            }

class PaymentService:
    def __init__(self):
        self.gateways = {
            'stripe': StripeGateway(api_key="sk_test_..."),
            'paypal': PayPalGateway(client_id="...", client_secret="...")
        }
    
    def process_payment(self, gateway: str, amount: float, currency: str, payment_method: str) -> Dict[str, Any]:
        if gateway not in self.gateways:
            return {'success': False, 'error': 'Unsupported payment gateway'}
        
        return self.gateways[gateway].process_payment(amount, currency, payment_method)
```

### 9.2 SMS and Email Notification Service

Create a notification service for sending SMS and email notifications:

```python
# services/notification-service/app/services/notification_service.py
from abc import ABC, abstractmethod
from typing import Dict, Any, List
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
from twilio.rest import Client

class NotificationProvider(ABC):
    @abstractmethod
    def send(self, recipient: str, message: str, subject: str = None) -> Dict[str, Any]:
        pass

class EmailProvider(NotificationProvider):
    def __init__(self, smtp_server: str, smtp_port: int, username: str, password: str):
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.username = username
        self.password = password
    
    def send(self, recipient: str, message: str, subject: str = None) -> Dict[str, Any]:
        try:
            msg = MIMEMultipart()
            msg['From'] = self.username
            msg['To'] = recipient
            msg['Subject'] = subject or "Notification"
            
            msg.attach(MIMEText(message, 'html'))
            
            server = smtplib.SMTP(self.smtp_server, self.smtp_port)
            server.starttls()
            server.login(self.username, self.password)
            server.send_message(msg)
            server.quit()
            
            return {'success': True, 'message': 'Email sent successfully'}
        except Exception as e:
            return {'success': False, 'error': str(e)}

class SMSProvider(NotificationProvider):
    def __init__(self, account_sid: str, auth_token: str, from_number: str):
        self.client = Client(account_sid, auth_token)
        self.from_number = from_number
    
    def send(self, recipient: str, message: str, subject: str = None) -> Dict[str, Any]:
        try:
            message = self.client.messages.create(
                body=message,
                from_=self.from_number,
                to=recipient
            )
            return {'success': True, 'message_sid': message.sid}
        except Exception as e:
            return {'success': False, 'error': str(e)}

class NotificationService:
    def __init__(self):
        self.providers = {
            'email': EmailProvider(
                smtp_server="smtp.gmail.com",
                smtp_port=587,
                username="your-email@gmail.com",
                password="your-password"
            ),
            'sms': SMSProvider(
                account_sid="your-twilio-sid",
                auth_token="your-twilio-token",
                from_number="+1234567890"
            )
        }
    
    def send_notification(self, provider: str, recipient: str, message: str, subject: str = None) -> Dict[str, Any]:
        if provider not in self.providers:
            return {'success': False, 'error': 'Unsupported notification provider'}
        
        return self.providers[provider].send(recipient, message, subject)
    
    def send_bulk_notification(self, provider: str, recipients: List[str], message: str, subject: str = None) -> List[Dict[str, Any]]:
        results = []
        for recipient in recipients:
            result = self.send_notification(provider, recipient, message, subject)
            results.append({'recipient': recipient, 'result': result})
        return results

# Usage example
notification_service = NotificationService()

# Send welcome email
notification_service.send_notification(
    provider='email',
    recipient='user@example.com',
    subject='Welcome to Our Service',
    message='''
    <h1>Welcome!</h1>
    <p>Thank you for joining our service. Your account has been created successfully.</p>
    <p>You can now log in and start using our services.</p>
    '''
)

# Send SMS notification
notification_service.send_notification(
    provider='sms',
    recipient='+1234567890',
    message='Your data quota is running low. Please recharge your account.'
)
```

## 10. Security Implementation

### 10.1 Authentication and Authorization

Implement comprehensive security measures:

```python
# services/auth-service/app/security.py
from fastapi import HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from passlib.context import CryptContext
from datetime import datetime, timedelta
from typing import Optional, List
import redis
import hashlib

security = HTTPBearer()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
redis_client = redis.Redis(host='localhost', port=6379, db=0)

SECRET_KEY = "your-secret-key-here"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
REFRESH_TOKEN_EXPIRE_DAYS = 7

class SecurityService:
    def __init__(self):
        self.pwd_context = pwd_context
        self.redis_client = redis_client
    
    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        return self.pwd_context.verify(plain_password, hashed_password)
    
    def get_password_hash(self, password: str) -> str:
        return self.pwd_context.hash(password)
    
    def create_access_token(self, data: dict, expires_delta: Optional[timedelta] = None):
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        
        to_encode.update({"exp": expire, "type": "access"})
        encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
        return encoded_jwt
    
    def create_refresh_token(self, data: dict):
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
        to_encode.update({"exp": expire, "type": "refresh"})
        
        encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
        
        # Store refresh token in Redis
        token_hash = hashlib.sha256(encoded_jwt.encode()).hexdigest()
        self.redis_client.setex(
            f"refresh_token:{token_hash}",
            timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS),
            data["sub"]
        )
        
        return encoded_jwt
    
    def verify_token(self, token: str, token_type: str = "access"):
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            
            if payload.get("type") != token_type:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid token type"
                )
            
            username: str = payload.get("sub")
            if username is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Could not validate credentials"
                )
            
            # For refresh tokens, check if it exists in Redis
            if token_type == "refresh":
                token_hash = hashlib.sha256(token.encode()).hexdigest()
                if not self.redis_client.exists(f"refresh_token:{token_hash}"):
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="Refresh token has been revoked"
                    )
            
            return username
        except JWTError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials"
            )
    
    def revoke_refresh_token(self, token: str):
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        self.redis_client.delete(f"refresh_token:{token_hash}")
    
    def check_permissions(self, user_role: str, required_permissions: List[str]) -> bool:
        role_permissions = {
            "super_admin": ["*"],
            "admin": ["user:read", "user:write", "billing:read", "billing:write", "nas:read", "nas:write"],
            "manager": ["user:read", "user:write", "billing:read"],
            "reseller": ["user:read", "user:write"],
            "user": ["profile:read", "profile:write"]
        }
        
        user_permissions = role_permissions.get(user_role, [])
        
        if "*" in user_permissions:
            return True
        
        return any(perm in user_permissions for perm in required_permissions)

security_service = SecurityService()

def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    username = security_service.verify_token(credentials.credentials)
    # Fetch user from database
    user = get_user_by_username(username)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found"
        )
    return user

def require_permissions(permissions: List[str]):
    def permission_checker(current_user = Depends(get_current_user)):
        if not security_service.check_permissions(current_user.role, permissions):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient permissions"
            )
        return current_user
    return permission_checker

# Usage in API endpoints
@app.get("/users")
async def get_users(current_user = Depends(require_permissions(["user:read"]))):
    # Only users with user:read permission can access this endpoint
    pass
```

### 10.2 Rate Limiting and DDoS Protection

Implement rate limiting to protect against abuse:

```python
# services/api-gateway/app/middleware/rate_limiting.py
from fastapi import HTTPException, Request, status
from fastapi.responses import JSONResponse
import redis
import time
from typing import Dict, Any
import hashlib

class RateLimiter:
    def __init__(self, redis_client: redis.Redis):
        self.redis_client = redis_client
    
    def is_allowed(self, key: str, limit: int, window: int) -> Dict[str, Any]:
        """
        Check if request is allowed based on rate limit
        
        Args:
            key: Unique identifier for the client (IP, user ID, etc.)
            limit: Maximum number of requests allowed
            window: Time window in seconds
        
        Returns:
            Dict with 'allowed' boolean and additional info
        """
        current_time = int(time.time())
        window_start = current_time - window
        
        # Use sliding window log algorithm
        pipe = self.redis_client.pipeline()
        
        # Remove old entries
        pipe.zremrangebyscore(key, 0, window_start)
        
        # Count current requests
        pipe.zcard(key)
        
        # Add current request
        pipe.zadd(key, {str(current_time): current_time})
        
        # Set expiration
        pipe.expire(key, window)
        
        results = pipe.execute()
        current_requests = results[1]
        
        if current_requests >= limit:
            return {
                'allowed': False,
                'limit': limit,
                'remaining': 0,
                'reset_time': current_time + window
            }
        
        return {
            'allowed': True,
            'limit': limit,
            'remaining': limit - current_requests - 1,
            'reset_time': current_time + window
        }

class RateLimitMiddleware:
    def __init__(self, redis_client: redis.Redis):
        self.rate_limiter = RateLimiter(redis_client)
        self.rate_limits = {
            'default': {'limit': 100, 'window': 3600},  # 100 requests per hour
            'auth': {'limit': 5, 'window': 300},        # 5 auth attempts per 5 minutes
            'api': {'limit': 1000, 'window': 3600},     # 1000 API calls per hour
        }
    
    async def __call__(self, request: Request, call_next):
        client_ip = request.client.host
        path = request.url.path
        
        # Determine rate limit category
        if path.startswith('/auth'):
            category = 'auth'
        elif path.startswith('/api'):
            category = 'api'
        else:
            category = 'default'
        
        # Create unique key for client
        key = f"rate_limit:{category}:{client_ip}"
        
        # Check rate limit
        rate_limit_info = self.rate_limiter.is_allowed(
            key,
            self.rate_limits[category]['limit'],
            self.rate_limits[category]['window']
        )
        
        if not rate_limit_info['allowed']:
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content={
                    "error": "Rate limit exceeded",
                    "limit": rate_limit_info['limit'],
                    "reset_time": rate_limit_info['reset_time']
                },
                headers={
                    "X-RateLimit-Limit": str(rate_limit_info['limit']),
                    "X-RateLimit-Remaining": str(rate_limit_info['remaining']),
                    "X-RateLimit-Reset": str(rate_limit_info['reset_time'])
                }
            )
        
        response = await call_next(request)
        
        # Add rate limit headers to response
        response.headers["X-RateLimit-Limit"] = str(rate_limit_info['limit'])
        response.headers["X-RateLimit-Remaining"] = str(rate_limit_info['remaining'])
        response.headers["X-RateLimit-Reset"] = str(rate_limit_info['reset_time'])
        
        return response
```

## 11. Testing Strategy

### 11.1 Unit Testing

Implement comprehensive unit tests for all services:

```python
# tests/test_user_service.py
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.main import app
from app.database import get_db, Base
from app.models import User

# Test database
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base.metadata.create_all(bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

class TestUserService:
    def setup_method(self):
        # Clear database before each test
        db = TestingSessionLocal()
        db.query(User).delete()
        db.commit()
        db.close()
    
    def test_create_user(self):
        user_data = {
            "username": "testuser",
            "email": "test@example.com",
            "password": "testpassword",
            "first_name": "Test",
            "last_name": "User"
        }
        
        response = client.post("/users", json=user_data)
        assert response.status_code == 200
        
        data = response.json()
        assert data["username"] == user_data["username"]
        assert data["email"] == user_data["email"]
        assert "id" in data
    
    def test_create_duplicate_user(self):
        user_data = {
            "username": "testuser",
            "email": "test@example.com",
            "password": "testpassword"
        }
        
        # Create first user
        response1 = client.post("/users", json=user_data)
        assert response1.status_code == 200
        
        # Try to create duplicate
        response2 = client.post("/users", json=user_data)
        assert response2.status_code == 400
        assert "already exists" in response2.json()["detail"]
    
    def test_get_users(self):
        # Create test users
        for i in range(3):
            user_data = {
                "username": f"testuser{i}",
                "email": f"test{i}@example.com",
                "password": "testpassword"
            }
            client.post("/users", json=user_data)
        
        response = client.get("/users")
        assert response.status_code == 200
        
        data = response.json()
        assert len(data) == 3
    
    def test_get_user_by_id(self):
        user_data = {
            "username": "testuser",
            "email": "test@example.com",
            "password": "testpassword"
        }
        
        create_response = client.post("/users", json=user_data)
        user_id = create_response.json()["id"]
        
        response = client.get(f"/users/{user_id}")
        assert response.status_code == 200
        
        data = response.json()
        assert data["username"] == user_data["username"]
    
    def test_get_nonexistent_user(self):
        response = client.get("/users/999")
        assert response.status_code == 404
    
    def test_update_user_status(self):
        user_data = {
            "username": "testuser",
            "email": "test@example.com",
            "password": "testpassword"
        }
        
        create_response = client.post("/users", json=user_data)
        user_id = create_response.json()["id"]
        
        response = client.put(f"/users/{user_id}/status", json={"status": "suspended"})
        assert response.status_code == 200
        
        # Verify status was updated
        get_response = client.get(f"/users/{user_id}")
        assert get_response.json()["status"] == "suspended"

# Run tests with: pytest tests/test_user_service.py -v
```

### 11.2 Integration Testing

Test the integration between services:

```python
# tests/test_integration.py
import pytest
import requests
import time
from concurrent.futures import ThreadPoolExecutor

class TestIntegration:
    def setup_class(self):
        self.base_url = "http://localhost:8000"
        self.auth_token = self.get_auth_token()
    
    def get_auth_token(self):
        response = requests.post(f"{self.base_url}/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        return response.json()["access_token"]
    
    def test_user_creation_and_radius_integration(self):
        """Test that creating a user also creates RADIUS entries"""
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        
        user_data = {
            "username": "radiustest",
            "email": "radiustest@example.com",
            "password": "testpass123",
            "service_plan_id": 1
        }
        
        # Create user
        response = requests.post(
            f"{self.base_url}/users",
            json=user_data,
            headers=headers
        )
        assert response.status_code == 200
        
        user_id = response.json()["id"]
        
        # Verify RADIUS entries were created
        radius_response = requests.get(
            f"{self.base_url}/radius/check/{user_data['username']}",
            headers=headers
        )
        assert radius_response.status_code == 200
        
        radius_data = radius_response.json()
        assert radius_data["username"] == user_data["username"]
        assert "Cleartext-Password" in [attr["attribute"] for attr in radius_data["check_attributes"]]
    
    def test_billing_integration(self):
        """Test billing service integration with user service"""
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        
        # Create user with service plan
        user_data = {
            "username": "billingtest",
            "email": "billingtest@example.com",
            "password": "testpass123",
            "service_plan_id": 1
        }
        
        user_response = requests.post(
            f"{self.base_url}/users",
            json=user_data,
            headers=headers
        )
        user_id = user_response.json()["id"]
        
        # Generate invoice
        invoice_response = requests.post(
            f"{self.base_url}/billing/invoices",
            json={"user_id": user_id},
            headers=headers
        )
        assert invoice_response.status_code == 200
        
        invoice_data = invoice_response.json()
        assert invoice_data["user_id"] == user_id
        assert invoice_data["amount"] > 0
    
    def test_concurrent_user_creation(self):
        """Test system behavior under concurrent load"""
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        
        def create_user(index):
            user_data = {
                "username": f"concurrent_user_{index}",
                "email": f"concurrent_{index}@example.com",
                "password": "testpass123"
            }
            
            response = requests.post(
                f"{self.base_url}/users",
                json=user_data,
                headers=headers
            )
            return response.status_code == 200
        
        # Create 50 users concurrently
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(create_user, i) for i in range(50)]
            results = [future.result() for future in futures]
        
        # All requests should succeed
        assert all(results)
    
    def test_rate_limiting(self):
        """Test rate limiting functionality"""
        # Make requests without authentication to trigger rate limiting
        responses = []
        for i in range(10):
            response = requests.get(f"{self.base_url}/users")
            responses.append(response.status_code)
        
        # Should get rate limited after several requests
        assert 429 in responses  # Too Many Requests
```

### 11.3 Load Testing

Use tools like Locust for load testing:

```python
# tests/load_test.py
from locust import HttpUser, task, between
import random

class RadiusSystemUser(HttpUser):
    wait_time = between(1, 3)
    
    def on_start(self):
        # Login and get auth token
        response = self.client.post("/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        
        if response.status_code == 200:
            self.auth_token = response.json()["access_token"]
            self.headers = {"Authorization": f"Bearer {self.auth_token}"}
        else:
            self.auth_token = None
            self.headers = {}
    
    @task(3)
    def view_dashboard(self):
        self.client.get("/dashboard", headers=self.headers)
    
    @task(2)
    def list_users(self):
        self.client.get("/users", headers=self.headers)
    
    @task(1)
    def create_user(self):
        user_id = random.randint(1000, 9999)
        user_data = {
            "username": f"loadtest_user_{user_id}",
            "email": f"loadtest_{user_id}@example.com",
            "password": "testpass123"
        }
        self.client.post("/users", json=user_data, headers=self.headers)
    
    @task(1)
    def view_billing(self):
        self.client.get("/billing/invoices", headers=self.headers)
    
    @task(1)
    def radius_authentication(self):
        # Simulate RADIUS authentication request
        auth_data = {
            "username": f"testuser_{random.randint(1, 100)}",
            "password": "testpass123",
            "nas_ip": "192.168.1.1"
        }
        self.client.post("/radius/auth", json=auth_data)

# Run with: locust -f tests/load_test.py --host=http://localhost:8000
```

## 12. Deployment and DevOps

### 12.1 Docker Configuration

Create Docker configurations for each service:

```dockerfile
# services/user-service/Dockerfile
FROM python:3.9-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY app/ ./app/

# Create non-root user
RUN useradd --create-home --shell /bin/bash app \
    && chown -R app:app /app
USER app

# Health check
HEALTHCHECK --interval=30s --timeout=30s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:8000/health || exit 1

EXPOSE 8000

CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### 12.2 Kubernetes Deployment

Create Kubernetes manifests for production deployment:

```yaml
# k8s/user-service-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: user-service
  labels:
    app: user-service
spec:
  replicas: 3
  selector:
    matchLabels:
      app: user-service
  template:
    metadata:
      labels:
        app: user-service
    spec:
      containers:
      - name: user-service
        image: radius-system/user-service:latest
        ports:
        - containerPort: 8000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: database-secret
              key: url
        - name: REDIS_URL
          value: "redis://redis-service:6379"
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
---
apiVersion: v1
kind: Service
metadata:
  name: user-service
spec:
  selector:
    app: user-service
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8000
  type: ClusterIP
```

### 12.3 CI/CD Pipeline

Create a GitLab CI/CD pipeline:

```yaml
# .gitlab-ci.yml
stages:
  - test
  - build
  - deploy

variables:
  DOCKER_REGISTRY: registry.gitlab.com/your-project
  KUBERNETES_NAMESPACE: radius-system

before_script:
  - docker login -u $CI_REGISTRY_USER -p $CI_REGISTRY_PASSWORD $CI_REGISTRY

test:
  stage: test
  image: python:3.9
  services:
    - postgres:13
    - redis:6
  variables:
    POSTGRES_DB: test_db
    POSTGRES_USER: test_user
    POSTGRES_PASSWORD: test_pass
    DATABASE_URL: postgresql://test_user:test_pass@postgres:5432/test_db
    REDIS_URL: redis://redis:6379
  script:
    - pip install -r requirements.txt
    - pytest tests/ --cov=app --cov-report=xml
  coverage: '/TOTAL.+?(\d+\%)$/'
  artifacts:
    reports:
      coverage_report:
        coverage_format: cobertura
        path: coverage.xml

build:
  stage: build
  script:
    - docker build -t $CI_REGISTRY_IMAGE/user-service:$CI_COMMIT_SHA services/user-service/
    - docker build -t $CI_REGISTRY_IMAGE/billing-service:$CI_COMMIT_SHA services/billing-service/
    - docker build -t $CI_REGISTRY_IMAGE/nas-service:$CI_COMMIT_SHA services/nas-service/
    - docker push $CI_REGISTRY_IMAGE/user-service:$CI_COMMIT_SHA
    - docker push $CI_REGISTRY_IMAGE/billing-service:$CI_COMMIT_SHA
    - docker push $CI_REGISTRY_IMAGE/nas-service:$CI_COMMIT_SHA
  only:
    - main
    - develop

deploy_staging:
  stage: deploy
  image: bitnami/kubectl:latest
  script:
    - kubectl config use-context staging
    - kubectl set image deployment/user-service user-service=$CI_REGISTRY_IMAGE/user-service:$CI_COMMIT_SHA -n $KUBERNETES_NAMESPACE
    - kubectl set image deployment/billing-service billing-service=$CI_REGISTRY_IMAGE/billing-service:$CI_COMMIT_SHA -n $KUBERNETES_NAMESPACE
    - kubectl rollout status deployment/user-service -n $KUBERNETES_NAMESPACE
    - kubectl rollout status deployment/billing-service -n $KUBERNETES_NAMESPACE
  environment:
    name: staging
    url: https://staging.radius-system.com
  only:
    - develop

deploy_production:
  stage: deploy
  image: bitnami/kubectl:latest
  script:
    - kubectl config use-context production
    - kubectl set image deployment/user-service user-service=$CI_REGISTRY_IMAGE/user-service:$CI_COMMIT_SHA -n $KUBERNETES_NAMESPACE
    - kubectl set image deployment/billing-service billing-service=$CI_REGISTRY_IMAGE/billing-service:$CI_COMMIT_SHA -n $KUBERNETES_NAMESPACE
    - kubectl rollout status deployment/user-service -n $KUBERNETES_NAMESPACE
    - kubectl rollout status deployment/billing-service -n $KUBERNETES_NAMESPACE
  environment:
    name: production
    url: https://radius-system.com
  when: manual
  only:
    - main
```

## 13. Monitoring and Maintenance

### 13.1 Monitoring Setup

Implement comprehensive monitoring with Prometheus and Grafana:

```yaml
# monitoring/prometheus-config.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  - "alert_rules.yml"

scrape_configs:
  - job_name: 'user-service'
    static_configs:
      - targets: ['user-service:8000']
    metrics_path: /metrics
    scrape_interval: 5s

  - job_name: 'billing-service'
    static_configs:
      - targets: ['billing-service:8000']
    metrics_path: /metrics
    scrape_interval: 5s

  - job_name: 'freeradius'
    static_configs:
      - targets: ['freeradius:9812']
    metrics_path: /metrics
    scrape_interval: 10s

  - job_name: 'postgres'
    static_configs:
      - targets: ['postgres-exporter:9187']

  - job_name: 'redis'
    static_configs:
      - targets: ['redis-exporter:9121']

alerting:
  alertmanagers:
    - static_configs:
        - targets:
          - alertmanager:9093
```

### 13.2 Application Metrics

Add metrics to your applications:

```python
# app/metrics.py
from prometheus_client import Counter, Histogram, Gauge, generate_latest
from fastapi import Response
import time

# Metrics
REQUEST_COUNT = Counter('http_requests_total', 'Total HTTP requests', ['method', 'endpoint', 'status'])
REQUEST_DURATION = Histogram('http_request_duration_seconds', 'HTTP request duration')
ACTIVE_USERS = Gauge('active_users_total', 'Number of active users')
RADIUS_AUTH_COUNT = Counter('radius_auth_total', 'Total RADIUS authentication requests', ['result'])
DATABASE_CONNECTIONS = Gauge('database_connections_active', 'Active database connections')

class MetricsMiddleware:
    def __init__(self, app):
        self.app = app
    
    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        
        start_time = time.time()
        
        async def send_wrapper(message):
            if message["type"] == "http.response.start":
                status_code = message["status"]
                duration = time.time() - start_time
                
                REQUEST_COUNT.labels(
                    method=scope["method"],
                    endpoint=scope["path"],
                    status=status_code
                ).inc()
                
                REQUEST_DURATION.observe(duration)
            
            await send(message)
        
        await self.app(scope, receive, send_wrapper)

@app.get("/metrics")
async def metrics():
    return Response(generate_latest(), media_type="text/plain")

# Update metrics in your business logic
def authenticate_user(username: str, password: str):
    try:
        # Authentication logic here
        result = perform_authentication(username, password)
        
        if result:
            RADIUS_AUTH_COUNT.labels(result='success').inc()
        else:
            RADIUS_AUTH_COUNT.labels(result='failure').inc()
        
        return result
    except Exception as e:
        RADIUS_AUTH_COUNT.labels(result='error').inc()
        raise
```

### 13.3 Log Management

Implement structured logging:

```python
# app/logging_config.py
import logging
import json
from datetime import datetime
from typing import Dict, Any

class JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno
        }
        
        # Add extra fields if present
        if hasattr(record, 'user_id'):
            log_entry['user_id'] = record.user_id
        
        if hasattr(record, 'request_id'):
            log_entry['request_id'] = record.request_id
        
        if record.exc_info:
            log_entry['exception'] = self.formatException(record.exc_info)
        
        return json.dumps(log_entry)

def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format='%(message)s',
        handlers=[
            logging.StreamHandler()
        ]
    )
    
    # Set JSON formatter for all handlers
    for handler in logging.root.handlers:
        handler.setFormatter(JSONFormatter())
    
    # Set specific log levels
    logging.getLogger("uvicorn").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)

# Usage in your application
logger = logging.getLogger(__name__)

def create_user(user_data: dict, current_user_id: int):
    logger.info(
        "Creating new user",
        extra={
            'user_id': current_user_id,
            'action': 'create_user',
            'target_username': user_data.get('username')
        }
    )
    
    try:
        # User creation logic
        new_user = User(**user_data)
        db.add(new_user)
        db.commit()
        
        logger.info(
            "User created successfully",
            extra={
                'user_id': current_user_id,
                'action': 'create_user',
                'target_user_id': new_user.id,
                'target_username': new_user.username
            }
        )
        
        return new_user
    except Exception as e:
        logger.error(
            "Failed to create user",
            extra={
                'user_id': current_user_id,
                'action': 'create_user',
                'error': str(e)
            },
            exc_info=True
        )
        raise
```

## 14. Scaling and Performance Optimization

### 14.1 Database Optimization

Implement database optimization strategies:

```python
# app/database_optimization.py
from sqlalchemy import create_engine, event
from sqlalchemy.pool import QueuePool
from sqlalchemy.orm import sessionmaker
import redis

# Connection pooling configuration
engine = create_engine(
    DATABASE_URL,
    poolclass=QueuePool,
    pool_size=20,           # Number of connections to maintain
    max_overflow=30,        # Additional connections allowed
    pool_pre_ping=True,     # Validate connections before use
    pool_recycle=3600,      # Recycle connections after 1 hour
    echo=False              # Set to True for SQL debugging
)

# Read replica configuration
read_engine = create_engine(
    READ_REPLICA_DATABASE_URL,
    poolclass=QueuePool,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
    pool_recycle=3600
)

# Session factories
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
ReadSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=read_engine)

# Redis for caching
redis_client = redis.Redis(
    host='redis',
    port=6379,
    db=0,
    decode_responses=True,
    max_connections=20
)

class DatabaseService:
    def __init__(self):
        self.cache = redis_client
        self.cache_ttl = 300  # 5 minutes
    
    def get_user_by_id(self, user_id: int, use_cache: bool = True):
        cache_key = f"user:{user_id}"
        
        if use_cache:
            # Try to get from cache first
            cached_user = self.cache.get(cache_key)
            if cached_user:
                return json.loads(cached_user)
        
        # Get from database (use read replica for read operations)
        db = ReadSessionLocal()
        try:
            user = db.query(User).filter(User.id == user_id).first()
            if user and use_cache:
                # Cache the result
                user_dict = {
                    'id': user.id,
                    'username': user.username,
                    'email': user.email,
                    'status': user.status
                }
                self.cache.setex(cache_key, self.cache_ttl, json.dumps(user_dict))
            return user
        finally:
            db.close()
    
    def invalidate_user_cache(self, user_id: int):
        """Invalidate user cache when user data is updated"""
        cache_key = f"user:{user_id}"
        self.cache.delete(cache_key)
    
    def get_users_paginated(self, skip: int = 0, limit: int = 100, filters: dict = None):
        """Optimized pagination with filtering"""
        db = ReadSessionLocal()
        try:
            query = db.query(User)
            
            # Apply filters
            if filters:
                if filters.get('status'):
                    query = query.filter(User.status == filters['status'])
                if filters.get('service_plan_id'):
                    query = query.filter(User.service_plan_id == filters['service_plan_id'])
                if filters.get('search'):
                    search_term = f"%{filters['search']}%"
                    query = query.filter(
                        (User.username.ilike(search_term)) |
                        (User.email.ilike(search_term)) |
                        (User.first_name.ilike(search_term)) |
                        (User.last_name.ilike(search_term))
                    )
            
            # Get total count for pagination
            total = query.count()
            
            # Apply pagination
            users = query.offset(skip).limit(limit).all()
            
            return {
                'users': users,
                'total': total,
                'skip': skip,
                'limit': limit
            }
        finally:
            db.close()

# Database event listeners for cache invalidation
@event.listens_for(User, 'after_update')
def invalidate_user_cache_on_update(mapper, connection, target):
    # This will be called after a user is updated
    cache_key = f"user:{target.id}"
    redis_client.delete(cache_key)

@event.listens_for(User, 'after_delete')
def invalidate_user_cache_on_delete(mapper, connection, target):
    # This will be called after a user is deleted
    cache_key = f"user:{target.id}"
    redis_client.delete(cache_key)
```

### 14.2 Caching Strategy

Implement multi-level caching:

```python
# app/caching.py
import redis
import json
import hashlib
from typing import Any, Optional, Callable
from functools import wraps
import asyncio

class CacheManager:
    def __init__(self):
        self.redis_client = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
        self.local_cache = {}  # In-memory cache for frequently accessed data
        self.local_cache_size = 1000
        self.default_ttl = 300  # 5 minutes
    
    def _generate_cache_key(self, prefix: str, *args, **kwargs) -> str:
        """Generate a consistent cache key from function arguments"""
        key_data = f"{prefix}:{args}:{sorted(kwargs.items())}"
        return hashlib.md5(key_data.encode()).hexdigest()
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache (local first, then Redis)"""
        # Try local cache first
        if key in self.local_cache:
            return self.local_cache[key]['value']
        
        # Try Redis cache
        value = self.redis_client.get(key)
        if value:
            try:
                parsed_value = json.loads(value)
                # Store in local cache if there's space
                if len(self.local_cache) < self.local_cache_size:
                    self.local_cache[key] = {'value': parsed_value}
                return parsed_value
            except json.JSONDecodeError:
                return value
        
        return None
    
    def set(self, key: str, value: Any, ttl: int = None) -> None:
        """Set value in both local and Redis cache"""
        ttl = ttl or self.default_ttl
        
        # Store in Redis
        if isinstance(value, (dict, list)):
            self.redis_client.setex(key, ttl, json.dumps(value))
        else:
            self.redis_client.setex(key, ttl, str(value))
        
        # Store in local cache
        if len(self.local_cache) < self.local_cache_size:
            self.local_cache[key] = {'value': value}
    
    def delete(self, key: str) -> None:
        """Delete from both caches"""
        self.redis_client.delete(key)
        self.local_cache.pop(key, None)
    
    def clear_local_cache(self) -> None:
        """Clear local cache"""
        self.local_cache.clear()

cache_manager = CacheManager()

def cache_result(prefix: str, ttl: int = 300):
    """Decorator to cache function results"""
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Generate cache key
            cache_key = cache_manager._generate_cache_key(prefix, *args, **kwargs)
            
            # Try to get from cache
            cached_result = cache_manager.get(cache_key)
            if cached_result is not None:
                return cached_result
            
            # Execute function and cache result
            result = func(*args, **kwargs)
            cache_manager.set(cache_key, result, ttl)
            
            return result
        return wrapper
    return decorator

def async_cache_result(prefix: str, ttl: int = 300):
    """Decorator to cache async function results"""
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Generate cache key
            cache_key = cache_manager._generate_cache_key(prefix, *args, **kwargs)
            
            # Try to get from cache
            cached_result = cache_manager.get(cache_key)
            if cached_result is not None:
                return cached_result
            
            # Execute function and cache result
            result = await func(*args, **kwargs)
            cache_manager.set(cache_key, result, ttl)
            
            return result
        return wrapper
    return decorator

# Usage examples
@cache_result("user_profile", ttl=600)  # Cache for 10 minutes
def get_user_profile(user_id: int):
    # Expensive database operation
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if user:
            return {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'profile_data': user.profile_data
            }
        return None
    finally:
        db.close()

@async_cache_result("user_stats", ttl=300)  # Cache for 5 minutes
async def get_user_statistics(user_id: int):
    # Expensive aggregation query
    db = SessionLocal()
    try:
        # Complex query to get user statistics
        stats = db.execute("""
            SELECT 
                COUNT(*) as total_sessions,
                SUM(bytes_in + bytes_out) as total_bytes,
                AVG(session_duration) as avg_session_duration
            FROM user_sessions 
            WHERE user_id = :user_id
        """, {'user_id': user_id}).fetchone()
        
        return {
            'total_sessions': stats.total_sessions,
            'total_bytes': stats.total_bytes,
            'avg_session_duration': stats.avg_session_duration
        }
    finally:
        db.close()
```

### 14.3 Horizontal Scaling

Implement horizontal scaling strategies:

```python
# app/load_balancer.py
import random
from typing import List, Dict, Any
import requests
import asyncio
import aiohttp

class ServiceRegistry:
    def __init__(self):
        self.services = {
            'user-service': [
                'http://user-service-1:8000',
                'http://user-service-2:8000',
                'http://user-service-3:8000'
            ],
            'billing-service': [
                'http://billing-service-1:8000',
                'http://billing-service-2:8000'
            ],
            'nas-service': [
                'http://nas-service-1:8000',
                'http://nas-service-2:8000'
            ]
        }
        self.health_status = {}
    
    async def health_check(self):
        """Periodically check health of all service instances"""
        while True:
            for service_name, instances in self.services.items():
                for instance in instances:
                    try:
                        async with aiohttp.ClientSession() as session:
                            async with session.get(f"{instance}/health", timeout=5) as response:
                                self.health_status[instance] = response.status == 200
                    except:
                        self.health_status[instance] = False
            
            await asyncio.sleep(30)  # Check every 30 seconds
    
    def get_healthy_instance(self, service_name: str) -> str:
        """Get a healthy instance using round-robin load balancing"""
        instances = self.services.get(service_name, [])
        healthy_instances = [
            instance for instance in instances 
            if self.health_status.get(instance, True)
        ]
        
        if not healthy_instances:
            raise Exception(f"No healthy instances available for {service_name}")
        
        return random.choice(healthy_instances)

class ServiceClient:
    def __init__(self, service_registry: ServiceRegistry):
        self.registry = service_registry
    
    async def make_request(self, service_name: str, method: str, path: str, **kwargs) -> Dict[str, Any]:
        """Make a request to a service with automatic failover"""
        max_retries = 3
        
        for attempt in range(max_retries):
            try:
                instance = self.registry.get_healthy_instance(service_name)
                url = f"{instance}{path}"
                
                async with aiohttp.ClientSession() as session:
                    async with session.request(method, url, **kwargs) as response:
                        if response.status < 500:  # Don't retry client errors
                            return await response.json()
                        else:
                            raise aiohttp.ClientError(f"Server error: {response.status}")
            
            except Exception as e:
                if attempt == max_retries - 1:
                    raise e
                await asyncio.sleep(0.5 * (2 ** attempt))  # Exponential backoff

# Usage in API Gateway
service_registry = ServiceRegistry()
service_client = ServiceClient(service_registry)

@app.on_event("startup")
async def startup_event():
    # Start health checking in background
    asyncio.create_task(service_registry.health_check())

@app.get("/api/users/{user_id}")
async def get_user(user_id: int):
    try:
        result = await service_client.make_request(
            service_name='user-service',
            method='GET',
            path=f'/users/{user_id}'
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=503, detail="Service unavailable")
```

This comprehensive implementation guide provides you with everything needed to build a production-ready RADIUS management system. The guide covers:

1. **System Architecture**: Microservices-based design with clear separation of concerns
2. **Technology Stack**: Modern, proven technologies for scalability and maintainability
3. **Implementation Examples**: Practical code samples for all major components
4. **Security**: Comprehensive security measures including authentication, authorization, and rate limiting
5. **Testing**: Unit, integration, and load testing strategies
6. **Deployment**: Docker, Kubernetes, and CI/CD pipeline configurations
7. **Monitoring**: Comprehensive monitoring and logging setup
8. **Scaling**: Strategies for horizontal scaling and performance optimization

The system is designed to be:
- **Scalable**: Can handle millions of users and thousands of concurrent sessions
- **Reliable**: High availability with failover and redundancy
- **Secure**: Multiple layers of security protection
- **Maintainable**: Clean architecture with comprehensive testing
- **Performant**: Optimized for high performance with caching and load balancing

You can start by implementing the core components and gradually add more advanced features as your system grows.

